package dev.airpods.spatiallab;

/**
 * Demonstrator renderer: two head-relative virtual speakers, basic ITD/ILD + crossfeed.
 * This is NOT a measured HRTF; not equivalent to Apple's spatial audio.
 * Input: interleaved signed 16-bit little-endian mono/stereo PCM.
 * Output: interleaved signed 16-bit little-endian stereo PCM.
 */
public final class SpatialProcessor {
    private final float[] leftHistory = new float[512];
    private final float[] rightHistory = new float[512];
    private int cursor = 0;
    private float smoothYaw = 0f;
    public synchronized byte[] process(byte[] src, int length, int channels, int sampleRate) {
        if (channels != 1 && channels != 2) throw new IllegalArgumentException("Only PCM16 mono/stereo");
        int frames = length / (channels * 2);
        byte[] out = new byte[frames * 4];
        for (int i = 0; i < frames; ++i) {
            int inAt = i * channels * 2;
            float l = shortLE(src, inAt) / 32768f;
            float r = channels == 2 ? shortLE(src, inAt + 2) / 32768f : l;
            leftHistory[cursor] = l;
            rightHistory[cursor] = r;
            // Smooth direction, avoid instant full-balance jumps on packet boundaries.
            smoothYaw += (HeadPose.yaw() - smoothYaw) * 0.001f;
            // Speaker sources at -35 deg and +35 deg in head-centered coordinates.
            float alphaL = (float) Math.toRadians(-35f - smoothYaw);
            float alphaR = (float) Math.toRadians(35f - smoothYaw);
            float leftEar = sourceAtEar(leftHistory, alphaL, true, sampleRate)
                          + sourceAtEar(rightHistory, alphaR, true, sampleRate);
            float rightEar = sourceAtEar(leftHistory, alphaL, false, sampleRate)
                           + sourceAtEar(rightHistory, alphaR, false, sampleRate);
            // Clear, exaggerated orientation demonstration: manual slider is audible
            // ONLY for PCM rendered by this app. This is NOT physical HRTF head tracking.
            float p = Math.max(-1f, Math.min(1f, smoothYaw / 70f));
            float gainL = (float)Math.sqrt((1f + p) * 0.5f);
            float gainR = (float)Math.sqrt((1f - p) * 0.5f);
            putShortLE(out, i * 4, limit(leftEar * 0.85f * gainL));
            putShortLE(out, i * 4 + 2, limit(rightEar * 0.85f * gainR));
            cursor = (cursor + 1) & 511;
        }
        return out;
    }
    private float sourceAtEar(float[] history, float angle, boolean leftEar, int rate) {
        float side = (float) Math.sin(angle);
        boolean far = leftEar ? side > 0 : side < 0;
        // 0..0.65 ms interaural timing difference + simple level attenuation.
        int delay = far ? Math.min(48, Math.round(Math.abs(side) * rate * 0.00060f)) : 0;
        int index = (cursor - delay + 512) & 511;
        float amplitude = far ? 0.42f + 0.20f * (1f - Math.abs(side)) : 0.85f;
        return history[index] * amplitude;
    }
    private static short shortLE(byte[] b, int i) { return (short) ((b[i] & 255) | (b[i+1] << 8)); }
    private static short limit(float v) { return (short) (Math.max(-1f, Math.min(1f, v)) * 32767f); }
    private static void putShortLE(byte[] b, int i, short v) { b[i] = (byte) v; b[i+1] = (byte) (v >> 8); }
}
