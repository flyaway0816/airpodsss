# AirPods Spatial Lab v0.8：增强初始化与响应诊断（实验性）

## 为什么换方法
用户在 Android 17 / Xiaomi M154FF 上分别测试 v0.7 的 ALT 和 DEF，均只收到 **1 条 20 字节 RTBuddy/0x17 短消息**（载荷 8 字节），`0x44/0x45` 传感器帧为 0；这是无法证明启动成功的。没有必要继续改角度计算公式。

## 本版实际改动
- 在经典蓝牙 AACP / L2CAP PSM 0x1001 建链后，严格按顺序写入：`HANDSHAKE` → `SET_FEATURE_FLAGS (0x4D)` → `REQUEST_NOTIFICATIONS (0x0F)` → **ALT 或 DEF 二选一**头追请求。指令参照 LibrePods 的 AACPManager 和 `pods-head-tracker` 项目；不代表适配 AirPods 5。
- 记录四次写入成功以及字节数，并区分**本地写入成功**与**耳机响应成功**（这两者不是一回事）。
- 在 `0x17` 短帧中打印 protobuf 风格的可解析字段数值：例如 `08 07 10 03` 代表字段1=7、字段2=3；**不将字段2=3主观解释成接受/拒绝**。
- 保留精确长度拆包、0x44/0x45长姿态帧验证、姿态变化计数与 A 模式左右试听。

## 手机测试
1. 强行停止 LibrePods（防止抢同一个 AACP 连接），戴上双耳，保持系统蓝牙已连接。
2. 优先使用 **「连接 AirPods（增强初始化 + ALT）」**，保持前台 20-30 秒；先正视前方，随后左右转头和点头。
3. 点击 **「复制0x17原始帧诊断」**，把文本发回聊天（可先屏蔽任何设备标识）。
4. 若没有0x44/0x45数据，先断开，再重新连接 **「增强初始化 + DEF」** 作为单独对照。
5. 重点比对：发送步骤成功、0x17短帧字段、是否有持续的 70+ 字节 0x17，以及数值是否随头部运动变化。

## 边界
- 仅成功生成 APK 并不代表安卓手机已支持系统级 AirPods 头部跟踪。
- 无 Root/厂商支持无法将非系统传感器注入 Android 系统 Spatializer。App 内 HRTF 渲染仍需要额外开发；左右声道试听不等于 HRTF。
- 不采集 MAC 地址；日志可能包含少量 0x17 数据字节，公开前请检查。

协议来源：
- https://github.com/librepods-org/librepods/blob/main/android/app/src/main/java/me/kavishdevar/librepods/bluetooth/AACPManager.kt
- https://github.com/batubozkan/pods-head-tracker/blob/main/airpods_ht_probe.py
