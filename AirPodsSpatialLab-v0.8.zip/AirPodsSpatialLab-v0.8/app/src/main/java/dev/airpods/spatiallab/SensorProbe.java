package dev.airpods.spatiallab;

import java.util.Locale;

/**
 * Diagnostic-only analysis of reconstructed AACP frames.
 * A matching opcode or all-zero orientation is NOT proof of live head tracking.
 * No MAC address, device name or other Bluetooth identity is stored.
 */
public final class SensorProbe {
    private int frames, opcode17, layout17, nonzero17, changed17;
    private int short17, sensorEnvelope17, unclassified17;
    private final java.util.Map<Integer,Integer> opcodeCounts = new java.util.HashMap<>();
    private int lastRaw2, lastRaw3;
    private boolean previousRaw;
    private long lastFrameTimeMs;
    private String first17 = "未发现 0x17 帧";
    private String latest17 = "未发现 0x17 帧";
    private String rawRange = "无";
    private float minYaw = Float.POSITIVE_INFINITY, maxYaw = Float.NEGATIVE_INFINITY;
    private float minPitch = Float.POSITIVE_INFINITY, maxPitch = Float.NEGATIVE_INFINITY;
    private int distinct;

    public synchronized void reset() {
        frames=opcode17=layout17=nonzero17=changed17=distinct=0;
        short17=sensorEnvelope17=unclassified17=0;
        opcodeCounts.clear();
        lastRaw2=lastRaw3=0;previousRaw=false;lastFrameTimeMs=0;
        first17=latest17="未发现 0x17 帧";rawRange="无";
        minYaw=minPitch=Float.POSITIVE_INFINITY;
        maxYaw=maxPitch=Float.NEGATIVE_INFINITY;
    }

    /** True means an actual change was seen in candidate data, NOT verified head movement. */
    public synchronized boolean observe(byte[] frame, long elapsedMs) {
        frames++;
        if(frame.length < 6 || (frame[0]&255)!=4 || frame[1]!=0 || (frame[2]&255)!=4 || frame[3]!=0)
            return false;
        int opcode=(frame[4]&255) | ((frame[5]&255)<<8);
        opcodeCounts.put(opcode,opcodeCounts.getOrDefault(opcode,0)+1);
        if(opcode!=0x17) return false;
        opcode17++;
        if(frame.length<70)short17++;
        if(frame.length>=12 && ((frame[10]&255)==0x44 || (frame[10]&255)==0x45))sensorEnvelope17++;
        else if(frame.length>=70)unclassified17++;
        latest17=describe(frame);
        if(opcode17==1) first17=latest17;
        AacpHeadDecoder.Candidate pose=AacpHeadDecoder.inspect(frame,frame.length);
        if(pose==null)return false;
        layout17++;
        // A zeros-only frame is formally compatible with the loose decoder, but is not proof of orientation.
        if(pose.raw2==0 && pose.raw3==0)return false;
        nonzero17++;
        minYaw=Math.min(minYaw,pose.yaw);maxYaw=Math.max(maxYaw,pose.yaw);
        minPitch=Math.min(minPitch,pose.pitch);maxPitch=Math.max(maxPitch,pose.pitch);
        boolean moved=previousRaw && (Math.abs(pose.raw2-lastRaw2)+Math.abs(pose.raw3-lastRaw3)>16);
        if(moved){changed17++;distinct++;}
        previousRaw=true;lastRaw2=pose.raw2;lastRaw3=pose.raw3;
        lastFrameTimeMs=elapsedMs;
        rawRange=String.format(Locale.US,"o2=%d o3=%d / yaw=%.1f pitch=%.1f",pose.raw2,pose.raw3,pose.yaw,pose.pitch);
        return moved;
    }

    private static String hexSegment(byte[] b,int from,int to) {
        StringBuilder out=new StringBuilder();
        for(int i=from;i<Math.min(to,b.length);i++)
            out.append(String.format(Locale.ROOT,"%02X",b[i]&255));
        return out.toString();
    }
    /** Only the opcode header and tentative orientation area; no Bluetooth address or full packets. */
    private static String describe(byte[] f) {
        int declared=f.length>=12?((f[10]&255)|((f[11]&255)<<8)):-1;
        return RtBuddyEnvelope.summarize(f)+" 头="+hexSegment(f,0,Math.min(20,f.length))
            +" 候选区[36..64]="+(f.length>36?hexSegment(f,36,Math.min(64,f.length)):"长度不足");
    }
    public synchronized int opcode17Count(){return opcode17;}
    public synchronized int changedCount(){return changed17;}
    public synchronized String summary() {
        String yawSpan=nonzero17==0?"无":String.format(Locale.US,"%.2f°",maxYaw-minYaw);
        String pitchSpan=nonzero17==0?"无":String.format(Locale.US,"%.2f°",maxPitch-minPitch);
        return "AACP候选帧="+frames+" / 0x17信封="+opcode17+" / 短命令="+short17
            +" / 姿态形状(0x44/0x45)="+sensorEnvelope17+" / 非姿态长帧="+unclassified17
            +" / 严格布局匹配="+layout17
            +" / 非零姿态="+nonzero17+" / 数值变化="+changed17
            +"\nYaw变化幅度="+yawSpan+" Pitch变化幅度="+pitchSpan
            +"\n最后一次匹配值："+rawRange;
    }
    public synchronized String report() {
        java.util.List<java.util.Map.Entry<Integer,Integer>> sorted = new java.util.ArrayList<>(opcodeCounts.entrySet());
        sorted.sort((a,b)->Integer.compare(b.getValue(),a.getValue()));
        StringBuilder top=new StringBuilder();
        for(int i=0;i<Math.min(8,sorted.size());i++) {
            java.util.Map.Entry<Integer,Integer> e=sorted.get(i);
            if(i>0)top.append(", ");
            top.append(String.format(Locale.ROOT,"0x%04X=%d",e.getKey(),e.getValue()));
        }
        return summary()+"\n收到的帧类型(候选帧首6字节推测)："+(top.length()>0?top.toString():"无")
            +"\n0x17按LE长度字段精确截帧，其它opcode仍靠下一同步头推断；仅当0x17形状为0x44/0x45且长度正确时才尝试姿态解析。"
            +"\n第一条0x17："+first17+"\n最后一条0x17："+latest17
            +"\n注意：日志只含截取的0x17候选数据，不含蓝牙地址。字节布局未经AirPods 5真机确认；计数、变化不证明方向正确。";
    }
}
