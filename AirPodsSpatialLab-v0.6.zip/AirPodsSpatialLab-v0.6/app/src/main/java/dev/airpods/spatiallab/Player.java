package dev.airpods.spatiallab;

import android.content.Context;
import android.media.*;
import android.net.Uri;
import java.io.IOException;
import java.nio.ByteBuffer;

/** Decode local compressed or PCM audio through MediaCodec and spatialize PCM16. */
public final class Player {
    public interface Status { void message(String m); }
    private volatile boolean stop = false;
    private Thread worker;
    private final SpatialProcessor dsp = new SpatialProcessor();
    public synchronized void play(Context context, Uri uri, Status status) {
        stop();
        stop = false;
        worker = new Thread(() -> decode(context, uri, status), "local-audio-decoder");
        worker.start();
    }
    public synchronized void stop() { stop = true; }

    /** Independent audible left/right positioning test, routed through this app's AudioTrack.
     * The slider controls this panning. It does NOT affect other apps' audio.
     * This is stereo-balance diagnostics, NOT true head-tracked spatial audio.
     */
    public synchronized void playPanningTest(Status status) {
        stop();
        stop = false;
        worker = new Thread(() -> playTestLoop(status), "audible-pan-test");
        worker.start();
    }

    private void playTestLoop(Status status) {
        AudioTrack track = null;
        final int sampleRate = 48000;
        final int frames = 960;
        final byte[] pcm = new byte[frames * 4];
        double phase = 0;
        try {
            track = makeTrack(sampleRate);
            track.play();
            status.message("A：左右试听音已开始，拖动头部模拟滑块至 -70° 和 +70° 应明显左右移动。此功能只检验本程序音频通路。");
            while(!stop && !Thread.currentThread().isInterrupted()) {
                for (int i=0;i<frames;i++) {
                    float p = Math.max(-1f, Math.min(1f, HeadPose.yaw() / 70f));
                    // +Yaw (head right) => fixed virtual source remains left.
                    float gainL = (float)Math.sqrt((1f+p)*0.5f);
                    float gainR = (float)Math.sqrt((1f-p)*0.5f);
                    float tone = (float)(0.13 * Math.sin(phase) + 0.045 * Math.sin(phase*2.0));
                    phase += 2.0 * Math.PI * 440.0 / sampleRate;
                    if(phase > Math.PI*2) phase -= Math.PI*2;
                    short l = (short)(Math.max(-1f,Math.min(1f,tone * gainL)) * 32767);
                    short r = (short)(Math.max(-1f,Math.min(1f,tone * gainR)) * 32767);
                    int n=i*4;
                    pcm[n]=(byte)l; pcm[n+1]=(byte)(l>>8);
                    pcm[n+2]=(byte)r; pcm[n+3]=(byte)(r>>8);
                }
                int done=0;
                while(!stop && done<pcm.length) {
                    int n=track.write(pcm,done,pcm.length-done,AudioTrack.WRITE_BLOCKING);
                    if(n<0) throw new IOException("试听声音写入失败 " + n);
                    if(n==0) break;
                    done+=n;
                }
            }
            status.message("A：试听音已停止");
        } catch(Exception e) {
            status.message("A：试听音失败：" + e.getClass().getSimpleName() + " / " + e.getMessage());
        } finally {
            if(track!=null) {try {track.pause();track.flush();} catch(Exception ignored){} track.release();}
        }
    }

    private void decode(Context context, Uri uri, Status status) {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec codec = null;
        AudioTrack track = null;
        try {
            extractor.setDataSource(context, uri, null);
            int idx = -1;
            MediaFormat inputFormat = null;
            for (int i=0;i<extractor.getTrackCount();i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { idx=i;inputFormat=f;break; }
            }
            if (idx < 0 || inputFormat == null) throw new IOException("找不到可解码音轨");
            extractor.selectTrack(idx);
            String mime = inputFormat.getString(MediaFormat.KEY_MIME);
            if (mime == null) throw new IOException("未知音频格式");
            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(inputFormat, null, null, 0);
            codec.start();
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean eosInput = false, eosOutput = false;
            int rate = inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 48000;
            int channels = inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
            while (!stop && !eosOutput) {
                if (!eosInput) {
                    int in = codec.dequeueInputBuffer(10000);
                    if (in >= 0) {
                        ByteBuffer buf = codec.getInputBuffer(in);
                        if (buf == null) throw new IOException("decoder buffer missing");
                        int size = extractor.readSampleData(buf, 0);
                        if (size < 0) { codec.queueInputBuffer(in,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);eosInput=true; }
                        else { codec.queueInputBuffer(in,0,size,extractor.getSampleTime(),0); extractor.advance(); }
                    }
                }
                int out = codec.dequeueOutputBuffer(info,10000);
                if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat f = codec.getOutputFormat();
                    rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    int encoding = f.containsKey(MediaFormat.KEY_PCM_ENCODING) ? f.getInteger(MediaFormat.KEY_PCM_ENCODING) : AudioFormat.ENCODING_PCM_16BIT;
                    if (encoding != AudioFormat.ENCODING_PCM_16BIT || (channels != 1 && channels != 2))
                        throw new IOException("仅支持16位PCM及1/2声道解码结果；当前编码=" + encoding + ", 声道=" + channels);
                    track = makeTrack(rate);
                    track.play();
                    status.message("A：本地解码和空间效果播放中（"+rate+" Hz）");
                } else if (out >= 0) {
                    ByteBuffer b = codec.getOutputBuffer(out);
                    if (b != null && info.size > 0) {
                        if (track == null) { track=makeTrack(rate);track.play(); }
                        b.position(info.offset);
                        b.limit(info.offset+info.size);
                        byte[] samples = new byte[info.size];b.get(samples);
                        byte[] processed = dsp.process(samples,samples.length,channels,rate);
                        int written = 0;
                        while (written < processed.length && !stop) {
                            int n = track.write(processed,written,processed.length-written,AudioTrack.WRITE_BLOCKING);
                            if (n <= 0) throw new IOException("AudioTrack write: " + n);
                            written += n;
                        }
                    }
                    codec.releaseOutputBuffer(out,false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) eosOutput = true;
                }
            }
            status.message(stop ? "A：已停止" : "A：播放结束");
        } catch (Exception e) { status.message("A：播放异常：" + e.getMessage()); }
        finally {
            if (track != null) { try {track.pause();track.flush();} catch(Exception ignored){} track.release(); }
            if (codec != null) { try {codec.stop();} catch(Exception ignored){} codec.release(); }
            extractor.release();
        }
    }
    public static AudioTrack makeTrack(int rate) {
        AudioFormat fmt = new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build();
        AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                // Prevent our re-render from feeding back into audio capture.
                .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_NONE).build();
        int min = AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT);
        return new AudioTrack(attrs,fmt,Math.max(32768,min*3),AudioTrack.MODE_STREAM,AudioManager.AUDIO_SESSION_ID_GENERATE);
    }
}
