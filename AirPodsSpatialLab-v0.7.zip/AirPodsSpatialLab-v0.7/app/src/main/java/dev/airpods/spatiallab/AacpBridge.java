package dev.airpods.spatiallab;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.ParcelUuid;
import org.lsposed.hiddenapibypass.HiddenApiBypass;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.Locale;

/**
 * Experimental BR/EDR AACP access through Android NON-SDK APIs.
 * Hidden API policies may prevent use on Xiaomi Android 17. Does not bypass
 * root restrictions or communicate with another app's private service.
 */
public final class AacpBridge {
    public interface Callback {void status(String message);}
    private static final String SENSOR_START_DEF =
        "04 00 04 00 17 00 00 00 10 00 10 00 08 A1 02 42 0B 08 0E 10 02 1A 05 01 40 9C 00 00";
    // ALT was confirmed to trigger a live head-pose stream on AirPods 4 ANC in
    // independent hardware work; support for this AirPods 5 model is unverified.
    // Never send ALT and DEF during the same session: they can interfere.
    private static final String SENSOR_START_ALT =
        "04 00 04 00 17 00 00 00 10 00 0F 00 08 73 42 0B 08 10 10 02 1A 05 01 40 9C 00 00";
    private final AtomicBoolean running=new AtomicBoolean(false);
    private volatile BluetoothSocket socket;
    private volatile int totalChunks, totalBytes;
    private final SensorProbe probe = new SensorProbe();
    public String diagnostics() {
        return "L2CAP读取="+totalChunks+"次 / "+totalBytes+"字节\n"+probe.summary();
    }
    public String diagnosticReport() {
        return "AirPods Spatial Lab 0.7 | Android 17\n"+diagnostics()+"\n"+probe.report();
    }
    public void connect(BluetoothDevice device,Callback callback){
        connect(device, callback, true);
    }
    public void connect(BluetoothDevice device,Callback callback,boolean useAlt){
        if(!running.compareAndSet(false,true)){callback.status("AACP：已有连接尝试");return;}
        new Thread(()->{
            int receivedChunks=0;
            totalChunks=totalBytes=0;
            probe.reset();
            final int[] accepted={0};
            AacpFrameStream framer=new AacpFrameStream();
            try{
                // Classic Bluetooth BR/EDR L2CAP PSM 0x1001 is not exposed by
                // the public Android BluetoothDevice.createL2capChannel API
                // (which creates a LE credit-based channel). Newer Android
                // releases changed BluetoothSocket constructor signatures.
                // HiddenApiBypass is attempted without root; it can still fail.
                callback.status("AACP：正在探测 Android 17 蓝牙套接字构造方式（免 Root）…");
                BluetoothSocket s=createClassicL2capSocket(device,callback);
                socket=s;
                callback.status("AACP：尝试连接经典蓝牙 L2CAP PSM 0x1001…");
                s.connect();
                callback.status("AACP：连接成功，使用"+(useAlt?"ALT":"DEF")+"请求0x17实验数据");
                OutputStream out=s.getOutputStream();
                out.write(AacpHeadDecoder.hex("00 00 04 00 01 00 02 00 00 00 00 00 00 00 00 00"));
                out.flush();
                try { Thread.sleep(200); } catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
                // A minimal handshake+START is used to avoid unrelated packets.
                // Do not send both START variants on one connection.
                out.write(AacpHeadDecoder.hex(useAlt ? SENSOR_START_ALT : SENSOR_START_DEF));
                out.flush();
                callback.status("AACP：已发送"+(useAlt?"ALT":"DEF")+"启动包；等待严格匹配的0x17姿态报文");
                byte[] chunk=new byte[4096];InputStream in=s.getInputStream();
                while(running.get()){
                    int n=in.read(chunk);
                    if(n<0){callback.status("AACP：对端已关闭数据流");break;}
                    receivedChunks++;
                    totalChunks=receivedChunks;
                    totalBytes+=n;
                    framer.accept(chunk,0,n,frame->{
                        boolean changed=probe.observe(frame,android.os.SystemClock.elapsedRealtime());
                        if(changed){
                            AacpHeadDecoder.Candidate c=AacpHeadDecoder.inspect(frame,frame.length);
                            if(c!=null){
                                accepted[0]++;
                                HeadPose.update(c.yaw,c.pitch,true);
                                if(accepted[0]==1) callback.status("AACP：发现首个数值变化的0x17候选！仍需转头动作比对，不能当作已验证的传感器。 ");
                            }
                        }
                    });
                    if(receivedChunks==40) callback.status("AACP：40个读取块。"+probe.summary());
                    if(receivedChunks%100==0)
                        callback.status("AACP：连接仍在接收。"+diagnostics());
                }
                callback.status("AACP：输入结束，数值变化候选帧="+accepted[0]);
            }catch(Throwable t){
                callback.status("AACP：连接/读取失败："+t.getClass().getSimpleName()+" / "+shortMessage(t)
                    +"。先区分构造方法、蓝牙权限、PSM 链路、帧解析四个环节；不能据此判断耳机是否支持头追。");
            }finally{running.set(false);BluetoothSocket s=socket;socket=null;
                if(s!=null)try{s.close();}catch(Exception ignored){}
            }
        },"aacp-reader").start();
    }
    /** Probe published LibrePods-compatible Android constructor families.
     *  Does not open LE CoC / RFCOMM as a misleading substitute for BR/EDR.
     */
    private static BluetoothSocket createClassicL2capSocket(BluetoothDevice device,Callback cb) throws Exception {
        BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
        final int TYPE_L2CAP=3;
        final int PSM_AACP=0x1001;
        // Multiple Android revisions/OEMs differ in argument order and arity.
        Object[][] candidates=new Object[][] {
            {adapter,device,TYPE_L2CAP,true,true,PSM_AACP,(ParcelUuid)null},
            {device,TYPE_L2CAP,true,true,PSM_AACP,(ParcelUuid)null},
            {device,TYPE_L2CAP,1,true,true,PSM_AACP,(ParcelUuid)null},
            {TYPE_L2CAP,1,true,true,device,PSM_AACP,(ParcelUuid)null},
            {TYPE_L2CAP,true,true,device,PSM_AACP,(ParcelUuid)null},
            {TYPE_L2CAP,1,true,true,device,PSM_AACP,(ParcelUuid)null,false,false}
        };
        Throwable last=null;
        for(int i=0;i<candidates.length;i++){
            try {
                BluetoothSocket result=(BluetoothSocket)HiddenApiBypass.newInstance(BluetoothSocket.class,candidates[i]);
                cb.status("AACP：套接字构造成功（方案 "+(i+1)+"/"+candidates.length+"），准备连接 PSM 0x1001");
                return result;
            }catch(Throwable t){
                last=t;
                cb.status("AACP：构造方案 "+(i+1)+" 未匹配（"+t.getClass().getSimpleName()+"）");
            }
        }
        throw new IllegalStateException("六种蓝牙套接字构造方式均不可用；最后原因："+shortMessage(last),last);
    }
    private static String shortMessage(Throwable t){
        if(t==null)return "unknown";
        String message=t.getMessage();
        if(message==null || message.isEmpty())return t.getClass().getSimpleName();
        return message.length()>190?message.substring(0,190):message;
    }
    public void close(){running.set(false);BluetoothSocket s=socket;socket=null;if(s!=null)try{s.close();}catch(Exception ignored){}}
}
