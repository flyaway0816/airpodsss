# AirPods Spatial Lab v0.2 — 面向 AirPods 5 的免 Root 安卓实验应用

**本目录是真正的 Android Java 源码工程（含 AndroidManifest、Gradle 和 A/B 双路径代码）。它不是 APK，也不是修改过的 LibrePods 官方 APK。** 本次制作过程受离线构建环境限制，未完成 Android SDK 全量编译，也无法接入用户的小米设备实测，**不能宣称已可在 AirPods 5 上实现动态头追**。

## 本次实际交付

- **A / 本地音乐：** 使用 `MediaExtractor` + `MediaCodec` 解码音频，转换到 PCM16，在 `SpatialProcessor` 做简化双耳 ITD/ILD 声场模拟，再由 `AudioTrack` 播放。能以滑块模拟转头；获取到可用的头部数据后，渲染模块会自动读取共享 `HeadPose`。
- **B / 第三方音频：** 基于 Android 官方 `AudioPlaybackCapture` 的 MediaProjection 授权，分为「仅监听音量」和「采集后重放」。后者无法压制原声音，可能出现回声或双音。禁止捕获的 App / 受 DRM 保护的内容不能绕过限制。
- **耳机传感器实验：** 独立于第三方 App 的私有服务，尝试通过 Android 隐藏 Classic L2CAP 通道连接 AACP PSM 0x1001、发送实验性的 0x17 指令。包含**跨蓝牙读入块的分帧重组**、帧头校验、候选方向数据解码、实时角度展示和诊断日志。
- **实验自检：** 使用完全模拟的 0x17 报文验证分帧、分包、基本角度解码；在界面有「运行协议分帧模拟自检」，另外 `tests/run-tests.sh` 用 JDK 执行共 8 项断言，无须设备。
- **设备检查：** 在界面查看安卓原生 Spatializer 可用性、是否识别官方 head tracker；不把这个状态误判为 AirPods 头追已支持。

## 能力边界与来源说明

1. **非 LibrePods 直接魔改版。** 我们没有取得 LibrePods 的完整 Android 仓库副本，因此无法在这份工程里保留 LibrePods 的降噪控制、设备电量、设置页面等现成功能；继续使用开发者发布的 FOSS 版本管理这些功能。本工程独立开发，只借鉴公开协议研究，没有复制其私有代码或绕过付费。
2. **Android 17 不自动开放经典 L2CAP。** 此项目尝试用隐藏的 `BluetoothSocket` 构造器；非 SDK 接口在小米 HyperOS 上可能被系统封锁。即使 LibrePods 已经能控制降噪，也不能证明本进程能够同时取得 AirPods 0x17 数据。
3. **协议研究没有 AirPods 5 真机证明。** GitHub 研究示例使用 0x17 和一个固定样本布局；另有讨论要求定位 `SensorDataWX` protobuf 后再解码。当前解码器保留清楚的候选布局和严格标记校验，并非通用固件解码器；解析成功仍需向左/向右/抬头三个方向实际核验。误解码可能产生假角度。
4. **没有实现苹果个人化空间音频 HRTF。** 当前声音渲染仅供方向性演示，绝不应当与苹果原生个人化空间音频、杜比 Atmos 混为一谈。
5. **A 与 B 都开发了可运行代码，不等于已无缝支持 QQ音乐、网易云音乐、B站。** 对其他 App 的音频捕获受其捕获策略和系统设置限制；本项目不会尝试绕过 DRM。

## 一键在 Windows 上构建 APK

前提：Windows 电脑已安装 Android Studio，**通过 SDK Manager 安装 Android SDK Platform 36**，并且可连接 Gradle 官方下载站点及 Google Maven。

1. 将 ZIP 压缩包完整解压，不要只打开压缩包预览。
2. 双击根目录的 **`build-windows.bat`**，脚本自动下载官方 Gradle 8.13（如本机没有）。如果需要 Android Studio 内置 Java，脚本会尝试自动检测 `jbr`。
3. 首次编译需要在线下载 Android Gradle 插件。成功后，APK 位于 `app/build/outputs/apk/debug/app-debug.apk`。
4. 手机蓝牙配对 AirPods 5 后，打开 APK 并按提示授权蓝牙。**先只用 A + 手动滑块测试**；确保音量低。
5. B 模式先选「仅监测」，看到 RMS 不为零后才考虑重放；重放可能出现回音。
6. 传感器实验建议在临时关闭 LibrePods 的后台连接之后启动，避免抢占控制通道。若报错 `InaccessibleObjectException / SecurityException / IOException`，保留诊断摘要；不能靠简单的 ADB/Shizuku 保证解除隐藏 API 和系统通道限制。

### 手动用 Android Studio 构建

Android Studio → Open → 选根目录 → 等待 Gradle 同步。如 IDE 无法处理缺失的 Wrapper，请优先运行 `build-windows.bat` 安装官方 Gradle，然后在 Studio 中选择本地安装的 Gradle，或在项目根目录执行 `gradle wrapper --gradle-version 8.13`。Android `targetSdk` 当前为 35，`compileSdk` 为 36，可在 Android 17 设备运行，能否访问私有蓝牙接口另论。

### 测试脚本

在带 Java 17+ 的 Linux/macOS 或 Git Bash 终端：

```bash
bash tests/run-tests.sh
```

**测试通过只证明纯 Java 分帧、候选解码和 PCM 运算能够运行，并不证明 Android APK 成功构建，更不证明 AirPods 5 真机通信成功。**

## 关键路径

- `app/src/main/java/dev/airpods/spatiallab/MainActivity.java`：模式与设备诊断界面
- `.../AacpBridge.java`：经典 L2CAP 实验、AACP 指令
- `.../AacpFrameStream.java`：跨 `InputStream.read()` 读取块重组候选报文
- `.../AacpHeadDecoder.java`：0x17 候选方向解析
- `.../HeadPose.java`：供 A / B 共用的方向状态和用户校准
- `.../SpatialProcessor.java`：ITD/ILD 音效模拟（非真实 HRTF）
- `.../Player.java`：A 本地音乐解码播放
- `.../CaptureService.java`：B 其他 App 播放捕获和（实验性）重放
- `tests/ProtocolTests.java`：8 项无需 Android SDK 的单元测试

## 权威参考

- Apple AirPods 5 无线盒官方规格：<https://support.apple.com/en-us/148760>
- LibrePods 官方状态与许可：<https://github.com/librepods-org/librepods>
- AACP 0x17 研究（未使用硬件验证）：<https://github.com/librepods-org/librepods/issues/713>
- SensorDataWX 动态偏移警告：<https://github.com/librepods-org/librepods/issues/719>
- Android MediaProjection / AudioPlaybackCapture：<https://developer.android.com/media/platform/av-capture>

**提示：** 仓库原始研究并未承诺此功能可在 AirPods 5 上免 Root 成功。实际蓝牙固件交互需要真实设备验证；不要从第三方网站安装所谓「LibrePods 头追破解 APK」。
