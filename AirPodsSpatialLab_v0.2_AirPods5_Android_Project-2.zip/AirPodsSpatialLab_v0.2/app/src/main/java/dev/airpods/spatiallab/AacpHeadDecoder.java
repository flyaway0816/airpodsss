package dev.airpods.spatiallab;

/**
 * Experimental AirPods head orientation decoder for AACP opcode 0x17.
 * Research: https://github.com/librepods-org/librepods/issues/719
 * This recognises ONE candidate layout, not all SensorDataWX variants.
 * Testing on AirPods 5 is required. Never claim its angles are validated.
 */
public final class AacpHeadDecoder {
    private AacpHeadDecoder() {}
    public static boolean decode(byte[] packet,int count) {
        if(packet==null || count<70 || count>packet.length)return false;
        if((packet[0]&255)!=4 || packet[1]!=0 || (packet[2]&255)!=4 || packet[3]!=0
                || (packet[4]&255)!=0x17 || packet[5]!=0 || (packet[8]&255)!=0x10) return false;
        // Notes in #719 say these offsets are relative to one observed header.
        // Future firmware must locate SensorDataWX protobuf payload dynamically.
        int o2=s16(packet,45),o3=s16(packet,47);
        float pitch= ((o2+o3)/2.0f/32000f)*180f;
        float yaw= ((o2-o3)/2.0f/32000f)*180f;
        if(!Float.isFinite(yaw)||!Float.isFinite(pitch))return false;
        // Reject apparent overflow or an unlikely frame; do not silently wrap.
        if(Math.abs(pitch)>110 || Math.abs(yaw)>110)return false;
        HeadPose.update(clamp(yaw,-70f,70f),clamp(pitch,-90f,90f),true);
        return true;
    }
    private static float clamp(float v,float min,float max){return Math.min(max,Math.max(min,v));}
    private static short s16(byte[] b,int at){return(short)((b[at]&255)|((b[at+1]&255)<<8));}
    public static byte[] hex(String src){
        String cleaned=src.replaceAll("[^0-9a-fA-F]","");
        if(cleaned.length()%2!=0)throw new IllegalArgumentException("odd hex characters");
        byte[] result=new byte[cleaned.length()/2];
        for(int i=0;i<result.length;i++)result[i]=(byte)Integer.parseInt(cleaned.substring(i*2,i*2+2),16);
        return result;
    }
}
