import dev.airpods.spatiallab.*;

public class ProtocolTests {
    private static int tested=0;
    private static void assertTrue(boolean ok,String why){tested++;if(!ok)throw new AssertionError(why);}
    public static void main(String[] args) {
        byte[] bad=new byte[80];
        assertTrue(!AacpHeadDecoder.decode(bad,bad.length),"reject junk");
        assertTrue(!AacpHeadDecoder.decode(null,0),"reject null");
        assertTrue(AacpHeadDecoder.hex("04 00").length==2,"parse hex");
        assertTrue(SpatialDiagnostics.exerciseParser().contains("通过"),"synthetic split packet");
        AacpFrameStream framer=new AacpFrameStream();
        byte[] a={9,8,7,4,0};byte[] b={4,0,1,0,0,0,4,0,4,0,2,0,0,0};
        final int[] hits={0};
        framer.accept(a,0,a.length,f->{hits[0]++;});
        framer.accept(b,0,b.length,f->{hits[0]++;});
        assertTrue(hits[0]==1,"reassemble header crossing input reads");
        HeadPose.update(35f,10f,false);HeadPose.center();
        assertTrue(Math.abs(HeadPose.yaw())<0.001f,"recenter");
        // Regression: previous self-test failed after centering because it used calibrated yaw.
        assertTrue(SpatialDiagnostics.exerciseParser().contains("通过"),"synthetic self test independent of recenter");
        assertTrue(Math.abs(HeadPose.yaw())<0.001f,"self-test must not alter active pose");
        assertTrue(!HeadPose.fromAirPods(),"simulator is not real AirPods");
        SpatialProcessor dsp=new SpatialProcessor();
        byte[] samples=new byte[480*4];
        for(int i=0;i<480;i++){
            short tone=(short)(9000*Math.sin(2*Math.PI*i/48));
            samples[i*4]=(byte)tone;samples[i*4+1]=(byte)(tone>>8);
            samples[i*4+2]=(byte)tone;samples[i*4+3]=(byte)(tone>>8);
        }
        byte[] output=dsp.process(samples,samples.length,2,48000);
        int energy=0;for(byte o:output)energy|=(o&0xff);
        assertTrue(output.length==samples.length && energy!=0,"renderer nonzero PCM stereo");
        SensorProbe probe=new SensorProbe();
        // 0x17 short command is not head orientation even when present.
        byte[] short17=AacpHeadDecoder.hex("04 00 04 00 17 00 00 00 10 00 08 00 08 10 10 01 00 00 00 00");
        assertTrue(!probe.observe(short17,1000),"short command cannot carry pose");
        assertTrue(probe.opcode17Count()==1 && probe.changedCount()==0,"short command is only protocol evidence");
        // Length-delimited sensor envelopes must reconstruct across reads.
        byte[] sample=new byte[80];
        sample[0]=4;sample[2]=4;sample[4]=0x17;sample[8]=0x10;sample[10]=0x44;
        sample[45]=0x10;sample[46]=0x27; // o2=10000
        sample[47]=(byte)0xf0;sample[48]=(byte)0xd8; // o3=-10000
        assertTrue(AacpHeadDecoder.inspect(sample,80)!=null,"valid orientation-shape envelope");
        byte[] badShape=sample.clone();badShape[10]=0x42;
        assertTrue(AacpHeadDecoder.inspect(badShape,80)==null,"reject non-motion long frame");
        byte[] fake=sample.clone();fake[11]=1;
        assertTrue(AacpHeadDecoder.inspect(fake,80)==null,"reject mismatching envelope length");
        AacpFrameStream precise=new AacpFrameStream();
        final int[] got={0};
        byte[] fused=new byte[sample.length+short17.length];
        System.arraycopy(sample,0,fused,0,sample.length);
        System.arraycopy(short17,0,fused,sample.length,short17.length);
        precise.accept(fused,0,13,p->{got[0]++;});
        precise.accept(fused,13,fused.length-13,p->{got[0]++;});
        assertTrue(got[0]==2,"strict 0x17 frames consume declared bytes");
        assertTrue(!probe.observe(sample,1100),"first pose no motion correlation");
        byte[] changed=sample.clone();changed[45]=(byte)0x90;
        assertTrue(probe.observe(changed,1200),"detect changed strict orientation candidate");
        assertTrue(probe.changedCount()==1 && probe.summary().contains("数值变化=1"),"strict sensor diagnostic");
        byte[] status=AacpHeadDecoder.hex("04 00 04 00 17 00 00 00 10 00 08 00 08 07 10 03 00 00 00 00");
        assertTrue(RtBuddyEnvelope.summarize(status).contains("字段1=7"),"parse 0x17 protobuf-style field1 without claiming ACK");
        assertTrue(RtBuddyEnvelope.summarize(status).contains("字段2=3"),"parse 0x17 protobuf-style field2 without interpreting result");
        assertTrue(!RtBuddyEnvelope.summarize(status).contains("已接受"),"do not pretend a short reply is sensor start accepted");
        byte[] truncated=status.clone();truncated[10]=20;
        assertTrue(RtBuddyEnvelope.summarize(truncated).contains("长度字段不一致"),"reject corrupted RTBuddy length");
        assertTrue(RtBuddyEnvelope.summarize(AacpHeadDecoder.hex("00 00 04 00 01 00 02 00 00 00 00 00 00 00 00 00")).contains("非RTBuddy"),"reject handshake as 0x17");
        System.out.println("PASS: "+tested+" tests");
    }
}
