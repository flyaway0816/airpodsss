# AirPods Spatial Lab v0.9：启动确认与连接所有权诊断（实验版）

针对小米 Android 17 / AirPods 5 的 **ALT 与 DEF 都已确认收到 StartAck，但没有实时运动帧** 的情况，新增更精细的只读协议诊断。

## 真机已观察到的事实
- ALT: `08 09 10 03 4A 02 08 10` → protobuf `StartAck(service=DEVMOTION6/16)`。
- DEF: `08 0A 10 03 4A 02 08 0E` → protobuf `StartAck(service=ACTIVITY/14)`。
- **StartAck ≠ 持续传感器输出。** 这两次均未观察到真实随运动变化的姿态帧。

## v0.9 与 v0.8 的区别
- 按公开 RTBuddy SensorDataWX protobuf 布局解析嵌套字段9(StartAck)和12(CommandAck)，避免将 ack 当姿态。
- 尝试只读解析普通 AACP 控制消息0x09内的标识0x06(OWNS_CONNECTION)，打印"未报告/1/0"。这不是证明拥有控制权的唯一方式，可能存在厂商差异。
- 未引入主动抢占、多设备接管或 root；继续保留 A/B 声音测试、ALT/DEF 双启动与严格长帧筛选。
- **此版仍然不能开启系统空间音频头追；只是有助于诊断。**

## 使用
1. 关闭 LibrePods 后连接 AirPods，优先选 ALT；戴好耳机。
2. 连接至少15秒，保持前台，复制 `0x17原始帧诊断`。
3. 看 `控制权报告=` / `StartAck=` / `姿态形状=` 三项。
4. 若控制权报告未收到，仅意味着当前分帧方式没识别到该状态；不能推定未拥有控制权。

无 Root 路线无法向系统 Spatializer 注入虚拟头部追踪传感器，应用内 HRTF 渲染需单独实现。不要将本实验 APK 当作已实现动态空间音频的产品。

参考协议：
- https://github.com/librepods-org/librepods/blob/main/android/app/src/main/java/me/kavishdevar/librepods/bluetooth/AACPManager.kt
- https://github.com/ntsour/Everypods/blob/main/android/app/src/main/proto/rtbuddy.proto
