package dev.airpods.spatiallab;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.Spatializer;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Root-free AirPods 5 (Wireless Charging Case) prototype dashboard for Xiaomi / Android 17. */
public final class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 101;
    private static final int REQUEST_CAPTURE_MONITOR = 102;
    private static final int REQUEST_CAPTURE_REPLAY = 103;
    private static final int REQUEST_BT = 104;
    private final Player player = new Player();
    private final AacpBridge bridge = new AacpBridge();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status, orientation, deviceInfo;
    private final ArrayDeque<String> recentMessages = new ArrayDeque<>();
    private boolean manualOverride = true;
    private boolean initialized = false;
    private final BroadcastReceiver captureMessages = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String message = intent.getStringExtra("message");if(message!=null)message(message);
        }
    };
    private void message(String line) {
        runOnUiThread(() -> {
            if (recentMessages.size()>=6) recentMessages.removeFirst();
            recentMessages.addLast(line);
            if (status!=null) status.setText(android.text.TextUtils.join("\n\n",recentMessages));
        });
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(13,19,31));
        getWindow().setNavigationBarColor(Color.rgb(13,19,31));
        buildUi();
        IntentFilter f=new IntentFilter(CaptureService.ACTION_UPDATE);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(captureMessages,f,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(captureMessages,f);
        initialized=true;
        updatePoseUi();
        message("A/B 双路径已初始化；AirPods 5 的实时头部追踪需验证蓝牙通道、SensorDataWX 帧布局和方向轴。");
    }
    private GradientDrawable background(int color,int radius) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;
    }
    private int dp(int value) {return (int)(getResources().getDisplayMetrics().density*value+0.5f);}
    private LinearLayout column() { LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l; }
    private TextView text(String s,int sp,int color) {
        TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);v.setLineSpacing(dp(3),1.12f);return v;
    }
    private void pad(LinearLayout l,View view,int top) {
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(top);l.addView(view,lp);
    }
    private TextView heading(LinearLayout c,String s) {
        TextView v=text(s,19,0xffffffff);v.setTypeface(null,Typeface.BOLD);pad(c,v,8);return v;
    }
    private void action(LinearLayout c,String title, Runnable onClick) {
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(14);
        b.setTextColor(0xff10243b);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffb7dcff));
        pad(c,b,9);b.setOnClickListener(v->onClick.run());
    }
    private LinearLayout card(LinearLayout root) {
        LinearLayout c=column();c.setPadding(dp(17),dp(14),dp(17),dp(17));
        c.setBackground(background(0xff1b2739,16));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(16);root.addView(c,lp);return c;
    }
    private void buildUi() {
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xff0d131f);
        LinearLayout root=column();root.setPadding(dp(18),dp(18),dp(18),dp(35));scroll.addView(root);
        TextView brand=text("AIRPODS 5   /   SPATIAL LAB",12,0xff91c9ff);brand.setLetterSpacing(0.15f);pad(root,brand,0);
        TextView headline=text("AirPods 5 动态空间音频\nA + B 双路径实验室",26,0xffffffff);headline.setTypeface(null,Typeface.BOLD);pad(root,headline,7);
        pad(root,text("无 Root · 小米 18 Pro Max / Android 17 · v0.2 开发实验版",13,0xffbecbe0),9);
        LinearLayout diagnostic=card(root);
        heading(diagnostic,"设备诊断 · AirPods 5 无线充电盒版");
        pad(diagnostic,text("AirPods 5 的耳机支持动态头部追踪；无线充电盒影响的是充电功能，不代表安卓手机已经具备头部追踪渲染。\n此处仅检测安卓原生空间化状态，不等于能接收 AirPods 5 运动数据。",12,0xffbcd0e4),6);
        deviceInfo=text(systemDescription(),13,0xffbcd0e4);pad(diagnostic,deviceInfo,6);
        action(diagnostic,"刷新系统空间音频状态",()->deviceInfo.setText(systemDescription()));

        LinearLayout tracker=card(root);
        heading(tracker,"01  头部追踪输入");
        pad(tracker,text("先用滑块模拟转头，确认音频随声场变化。随后尝试 AirPods 5 的 AACP 蓝牙传感器直连。",13,0xffbcd0e4),8);
        orientation=text("Yaw: 0°   Pitch: 0°",17,0xff91d7ff);orientation.setTypeface(null,Typeface.BOLD);pad(tracker,orientation,12);
        SeekBar yaw=new SeekBar(this);yaw.setMax(140);yaw.setProgress(70);pad(tracker,yaw,7);
        yaw.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s,int p,boolean fromUser) {if(fromUser) {manualOverride=true;HeadPose.update(p-70,0,false);}}
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        action(tracker,"重置正前方（校准）",()->{HeadPose.center();message("头部正前方已校准");});
        action(tracker,"连接已配对 AirPods 5（实验性）",this::chooseAirPods);
        action(tracker,"断开实验性 AACP 连接",()->{bridge.close();message("AACP：连接已停止");});
        action(tracker,"运行协议分帧模拟自检",()->message(SpatialDiagnostics.exerciseParser()));
        pad(tracker,text("提示：LibrePods 可能已占用同一 AACP 连接。此按钮尝试隐藏蓝牙接口，小米 Android 17 可能拒绝。失败不会影响 A/B 模拟音效，也不代表耳机不支持。",12,0xffffcf97),8);

        LinearLayout local=card(root);
        heading(local,"A  本地音频模式");
        pad(local,text("从手机选择音乐文件 → 安卓解码 → 头部方位关联的左右声道处理 → AirPods 输出。\n支持系统解码器能输出 PCM16 的音频格式。",13,0xffbcd0e4),7);
        action(local,"选择歌曲并播放（A）",()->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i,REQUEST_AUDIO);
        });
        action(local,"停止本地播放",()->{player.stop();message("A：停止请求已发出");});

        LinearLayout other=card(root);
        heading(other,"B  其他应用音频实验");
        pad(other,text("安卓官方 AudioPlaybackCapture：只捕获其他应用允许共享的音频。\n首先使用“只监测”查看能否读到数据；重放实验可能与原声音重叠而产生回声。",13,0xffbcd0e4),7);
        action(other,"开始采集测试（B · 不重放）",()->askCapture(false));
        action(other,"实验：采集并空间化重放（B）",()->askCapture(true));
        action(other,"停止 B 音频采集",()->{
            Intent i=new Intent(this,CaptureService.class);i.setAction(CaptureService.ACTION_STOP);startService(i);
            message("B：停止请求已发出");
        });
        pad(other,text("⚠ QQ音乐 / 网易云 / B站是否允许采集取决于各自策略和系统版本。没有 Root 无法全局静音原音，更不能绕过 DRM。",12,0xffffcf97),10);

        LinearLayout logs=card(root);
        heading(logs,"运行日志");
        status=text("尚无日志",12,0xffcee6ff);status.setTextIsSelectable(true);pad(logs,status,8);
        action(logs,"复制诊断摘要（不含蓝牙地址）",()->{
            String summary=systemDescription()+"\n"+status.getText().toString();
            android.content.ClipboardManager cb=getSystemService(android.content.ClipboardManager.class);
            cb.setPrimaryClip(ClipData.newPlainText("AirPods Spatial Lab report",summary));
            Toast.makeText(this,"已复制诊断摘要",Toast.LENGTH_SHORT).show();
        });
        pad(root,text("此原型的音效为 ITD/ILD 简化空间处理，不是 Apple 原生个性化 HRTF。请先调低音量。",12,0xffa1b5c9),18);
        setContentView(scroll);
    }
    private String systemDescription() {
        String s="设备："+Build.MANUFACTURER+" "+Build.MODEL+"\nAndroid："+Build.VERSION.RELEASE+" / API "+Build.VERSION.SDK_INT;
        if(Build.VERSION.SDK_INT>=32) {
            try {
                AudioManager am=getSystemService(AudioManager.class);
                Spatializer sp=am.getSpatializer();
                s+="\n系统空间化："+(sp.isAvailable()?"可用":"当前不可用")
                    +" / "+(sp.isEnabled()?"已开启":"未开启");
                if(Build.VERSION.SDK_INT>=33) s+="\n系统识别耳机头部追踪："+(sp.isHeadTrackerAvailable()?"是":"否");
            }catch(Exception e){s+="\n空间音频检测失败："+e.getMessage();}
        }
        return s;
    }
    private void updatePoseUi() {
        if(!initialized)return;
        String source=HeadPose.fromAirPods()?"AirPods 传感器（未校验坐标系）":"模拟/无实时 AirPods 数据";
        orientation.setText(String.format(Locale.CHINA,"Yaw: %.1f°   Pitch: %.1f°\n来源：%s",HeadPose.yaw(),HeadPose.pitch(),source));
        handler.postDelayed(this::updatePoseUi,200);
    }
    private void chooseAirPods() {
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQUEST_BT);
            message("已请求蓝牙权限，授权后请再次点击连接");return;
        }
        BluetoothManager manager=getSystemService(BluetoothManager.class);
        BluetoothAdapter adapter=manager.getAdapter();
        if(adapter==null || !adapter.isEnabled()){message("AACP：请先打开蓝牙");return;}
        ArrayList<BluetoothDevice> devices=new ArrayList<>();
        for(BluetoothDevice d:adapter.getBondedDevices()) {
            String name=d.getName();if(name!=null && (name.toLowerCase(Locale.ROOT).contains("airpods") || name.contains("耳机"))) devices.add(d);
        }
        if(devices.isEmpty()){message("AACP：找不到名称含 AirPods 的已配对设备；请先在系统蓝牙设置配对");return;}
        String[] names=new String[devices.size()];for(int i=0;i<names.length;i++)names[i]=devices.get(i).getName();
        new AlertDialog.Builder(this).setTitle("选择 AirPods 5（若更名，确认后选择）")
            .setItems(names,(d,which)->{
                message("尝试与 "+names[which]+" 建立实验性 AACP 连接…");
                bridge.connect(devices.get(which),this::message);
            }).setNegativeButton("取消",null).show();
    }
    private void askCapture(boolean replay) {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},105);
            message("请先授予麦克风/音频录制权限，然后再次点击 B 按钮");return;
        }
        MediaProjectionManager mpm=getSystemService(MediaProjectionManager.class);
        startActivityForResult(mpm.createScreenCaptureIntent(),replay?REQUEST_CAPTURE_REPLAY:REQUEST_CAPTURE_MONITOR);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==REQUEST_AUDIO && result==RESULT_OK && data!=null){
            Uri uri=data.getData();if(uri!=null){message("A：已选择音频，正在初始化播放器");player.play(this,uri,this::message);}
        }
        if((request==REQUEST_CAPTURE_MONITOR || request==REQUEST_CAPTURE_REPLAY) && result==RESULT_OK && data!=null){
            boolean monitor=request==REQUEST_CAPTURE_MONITOR;
            Intent i=new Intent(this,CaptureService.class);i.setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_RESULT,result).putExtra(CaptureService.EXTRA_CONSENT,data)
                .putExtra(CaptureService.EXTRA_MONITOR,monitor);
            startForegroundService(i);
        }
    }
    @Override protected void onDestroy() {
        initialized=false;handler.removeCallbacksAndMessages(null);player.stop();bridge.close();
        try {unregisterReceiver(captureMessages);}catch(Exception ignored){}
        super.onDestroy();
    }
}
