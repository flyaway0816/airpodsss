package dev.airpods.spatiallab;
/** Read-only parser for AACP control status notifications, opcode 0x09.
 *  This is a diagnostic interpretation of a vendor protocol, not a command to take over.
 */
public final class AacpControlState {
    public static final int UNKNOWN=-1;
    private AacpControlState(){}
    /** Ownership status from control identifier 0x06; 0 / 1 are tentative. */
    public static int ownership(byte[] f){
        if(f==null || f.length<8 || f[0]!=4 || f[1]!=0 || f[2]!=4 || f[3]!=0 ||
          (f[4]&255)!=9 || f[5]!=0 || (f[6]&255)!=6)return UNKNOWN;
        int value=f[7]&255;
        return value==0 || value==1 ? value : UNKNOWN;
    }
    public static String describe(int state){
        if(state==1)return "1：设备报告拥有控制权（仍需验证）";
        if(state==0)return "0：设备报告未拥有控制权（仍需验证）";
        return "未知／未收到标识0x06的0x09状态";
    }
}
