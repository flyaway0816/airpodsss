package dev.airpods.spatiallab;

import java.util.Arrays;

/**
 * Incremental AACP transport reader. An InputStream read is NOT an AACP packet:
 * L2CAP bytes may arrive split across reads or coalesced into one read.
 *
 * This diagnostic parser uses the documented 04 00 04 00 magic to find
 * candidate frames. Its framing policy is experimental (no vendor guarantee);
 * a match inside a payload could cause a false boundary. Never enable it as a
 * trusted device-orientation source without verifying on real hardware.
 */
public final class AacpFrameStream {
    public interface Listener { void candidate(byte[] frame); }
    private static final byte[] MARK = { 4,0,4,0 };
    private static final int MAX_BUFFER = 16384;
    private byte[] buf = new byte[2048];
    private int used;
    private int discarded;
    private int frames;

    public synchronized void accept(byte[] data, int offset, int len, Listener listener) {
        if (data==null || listener==null || offset<0 || len<0 || offset+len>data.length)
            throw new IllegalArgumentException("invalid stream chunk");
        if (len==0)return;
        if(used+len>MAX_BUFFER) { // resync if a peer sends unrecognisable framing
            discarded+=used;used=0;
            if(len>MAX_BUFFER) {offset+=len-MAX_BUFFER;len=MAX_BUFFER;}
        }
        if(buf.length<used+len) buf=Arrays.copyOf(buf,Math.min(MAX_BUFFER,Math.max(buf.length*2,used+len)));
        System.arraycopy(data,offset,buf,used,len);used+=len;
        while(true) {
            int first=findMark(0);
            if(first<0) {
                // Retain 3 tail bytes in case the marker is split by the read.
                int keep=Math.min(3,used);
                discarded+=used-keep;
                System.arraycopy(buf,used-keep,buf,0,keep);used=keep;return;
            }
            if(first>0){discarded+=first;drop(first);}
            int second=findMark(4);
            if(second<0)return;  // Wait for next frame header.
            if(second>=8) { listener.candidate(Arrays.copyOf(buf,second)); frames++; }
            else discarded+=second;
            drop(second);
        }
    }
    private int findMark(int start) {
        for(int i=start;i+MARK.length<=used;i++) {
            boolean match=true;
            for(int j=0;j<MARK.length;j++)if(buf[i+j]!=MARK[j]) {match=false;break;}
            if(match)return i;
        }
        return -1;
    }
    private void drop(int n) {System.arraycopy(buf,n,buf,0,used-n);used-=n;}
    public synchronized int emittedFrames() {return frames;}
    public synchronized int discardedBytes() {return discarded;}
    public synchronized int bufferedBytes() {return used;}
}
