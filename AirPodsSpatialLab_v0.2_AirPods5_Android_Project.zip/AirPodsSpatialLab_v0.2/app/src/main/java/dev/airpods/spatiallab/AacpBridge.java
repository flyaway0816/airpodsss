package dev.airpods.spatiallab;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.ParcelUuid;
import java.lang.reflect.Constructor;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Experimental BR/EDR AACP access through Android NON-SDK APIs.
 * Hidden API policies may prevent use on Xiaomi Android 17. Does not bypass
 * root restrictions or communicate with another app's private service.
 */
public final class AacpBridge {
    public interface Callback {void status(String message);}
    private static final String SENSOR_START =
        "04 00 04 00 17 00 00 00 10 00 10 00 08 A1 02 42 0B 08 0E 10 02 1A 05 01 40 9C 00 00";
    private final AtomicBoolean running=new AtomicBoolean(false);
    private volatile BluetoothSocket socket;
    public void connect(BluetoothDevice device,Callback callback){
        if(!running.compareAndSet(false,true)){callback.status("AACP：已有连接尝试");return;}
        new Thread(()->{
            int receivedChunks=0;
            final int[] accepted={0};
            AacpFrameStream framer=new AacpFrameStream();
            try{
                // BluetoothSocket.TYPE_L2CAP is a hidden field on some Android SDKs.
                // AOSP's classic L2CAP type value is 3, NOT public LE CoC.
                Constructor<BluetoothSocket> c=BluetoothSocket.class.getDeclaredConstructor(
                    int.class,int.class,boolean.class,boolean.class,BluetoothDevice.class,int.class,ParcelUuid.class);
                c.setAccessible(true);
                BluetoothSocket s=c.newInstance(3,-1,true,true,device,0x1001,null);
                socket=s;
                callback.status("AACP：尝试连接经典蓝牙 L2CAP PSM 0x1001…");
                s.connect();
                callback.status("AACP：连接成功；请求实验性 0x17 数据流");
                OutputStream out=s.getOutputStream();
                out.write(AacpHeadDecoder.hex("00 00 04 00 01 00 02 00 00 00 00 00 00 00 00 00"));
                out.write(AacpHeadDecoder.hex("04 00 04 00 0F 00 FF FF FF FF"));
                out.write(AacpHeadDecoder.hex(SENSOR_START));
                out.flush();
                byte[] chunk=new byte[4096];InputStream in=s.getInputStream();
                while(running.get()){
                    int n=in.read(chunk);
                    if(n<0)break;
                    receivedChunks++;
                    framer.accept(chunk,0,n,frame->{
                        if(AacpHeadDecoder.decode(frame,frame.length)){
                            accepted[0]++;
                            if(accepted[0]==1) callback.status("AACP：检测到首帧候选头部数据！请左右转头核对方向");
                        }
                    });
                    if(receivedChunks==40&&accepted[0]==0)
                        callback.status("AACP：已收40段蓝牙数据，尚无可识别头部帧。可能是固件布局不同。");
                    if(receivedChunks%200==0)
                        callback.status("AACP：数据块="+receivedChunks+" 候选帧="+framer.emittedFrames()
                            +" 头部候选="+accepted[0]+" / 待缓冲="+framer.bufferedBytes());
                }
                callback.status("AACP：输入结束，解析头部候选帧="+accepted[0]);
            }catch(Throwable t){
                callback.status("AACP：实验入口失败："+t.getClass().getSimpleName()+" / "+t.getMessage()
                    +"；这通常表示系统禁止隐藏蓝牙 API，并非耳机不支持头追。");
            }finally{running.set(false);BluetoothSocket s=socket;socket=null;
                if(s!=null)try{s.close();}catch(Exception ignored){}
            }
        },"aacp-reader").start();
    }
    public void close(){running.set(false);BluetoothSocket s=socket;socket=null;if(s!=null)try{s.close();}catch(Exception ignored){}}
}
