# AirPods 5（无线充电盒款）无 Root 适配测试计划

设备：小米 18 Pro Max；Android 17（以上依据用户所述，先在手机设置中核实）。
目标：A 模式本地音乐动态空间音频；B 模式第三方应用音频捕获试验。

## 0：区别产品与平台限制
- 苹果官方确认 AirPods 5（配无线充电盒）自身支持动态头部追踪。
- LibrePods 已适配 AirPods 5 基础控制；其 README 明确目前不向 Android 系统提供头追信息以实现系统 HRTF。
- 无线充电盒不提供实现动态头追所需的系统音频处理权限；真正关键是耳机运动数据读取与声音重渲染。

## 1：最小可验证项（不会碰 LibrePods 连接）
1. Android Studio 导入并尝试构建；记录完整错误，不要据此推断手机支持 AACP。
2. 蓝牙连接 AirPods 5 后，打开软件诊断页，记录 API Level、系统空间化是否可用，以及系统头追可用性。
3. 使用 A 本地播放器播放本地无 DRM 歌曲，缓慢拉动水平角度滑块，确认左右声像变化；这里**只是模拟**。
4. B 先选择「采集测试（不重放）」，在明确允许采集的 App 内播放音频，观察 RMS；避免 DRM 视频/音乐。
5. 只有完成 A/B 上述步骤之后，才考虑 B 重放（可能产生双音/回声）。

## 2：蓝牙头部追踪探索（风险较高、需单独验证）
1. 关闭 LibrePods 的后台 AACP 服务，防止竞争连接，耳机音量调低。
2. 选择「连接已配对 AirPods 5（实验性）」；若被 Android 17/HyperOS 的隐藏 API 拦截，不要误判为耳机不支持。
3. 仅在能建立稳定 AACP 连接后收集匿名化日志（不记录 MAC、序列号、配对密钥或其他个人信息）。
4. 根据 0x17 帧结构验证对齐、方向正负、俯仰与偏航的轴映射，开发滚转及 IMU 滤波。
5. 匹配头部姿态时间戳与音频渲染时间，逐渐替换当前简化 ITD/ILD 效果。

## 3：成败标准
- 已达成：模拟角度控制音效的源码路径存在（待 Android 构建与真机验证）。
- 未达成：AirPods 5 实际发送 0x17 报文、可靠解算真实姿态、HRTF 音效、第三方 App 无重复声音全局接管。
- B 模式只处理 Android 允许捕获的音频，无法保证 QQ 音乐、网易云、B 站。

官方来源：
- https://www.apple.com.cn/airpods-5/specs/
- https://github.com/librepods-org/librepods
- https://github.com/librepods-org/librepods/issues/713
- https://developer.android.com/media/platform/av-capture
