package dev.airpods.spatiallab;
/** Read-only RTBuddy SensorDataWX envelope parser. Do not treat START_ACK as a live motion stream. */
public final class RtBuddyEnvelope {
    private RtBuddyEnvelope() {}
    public static final int NO_ACK = -1;
    public static final class Result {
        public final int seq, logType, startAckService, commandAckService, payloadLength;
        Result(int seq, int logType, int startAckService, int commandAckService, int payloadLength) {
            this.seq=seq;this.logType=logType;this.startAckService=startAckService;
            this.commandAckService=commandAckService;this.payloadLength=payloadLength;
        }
    }
    private static final class Varint {
        long value;int next;
        Varint(long value,int next){this.value=value;this.next=next;}
    }
    private static Varint readVar(byte[] b,int pos,int end){
        long value=0;int shift=0;
        for(int j=0;j<10 && pos<end;j++) {
            int current=b[pos++]&255;
            value|=((long)(current&127))<<shift;
            if((current&128)==0)return new Varint(value,pos);
            shift+=7;
        }
        return null;
    }
    /** protobuf SensorTypeAck {service=field1}. Limits are enforced; invalid frames do not yield an ACK. */
    private static int nestedService(byte[] b,int pos,int end) {
        while(pos<end){
            Varint key=readVar(b,pos,end);if(key==null)return NO_ACK;
            pos=key.next;int field=(int)(key.value>>>3),wire=(int)(key.value&7);
            if(field==0)return NO_ACK;
            if(wire==0){Varint v=readVar(b,pos,end);if(v==null)return NO_ACK;
                pos=v.next;if(field==1 && v.value<=255)return (int)v.value;
            }else if(wire==2){Varint l=readVar(b,pos,end);if(l==null || l.value>end-l.next)return NO_ACK;
                pos=l.next+(int)l.value;
            }else{return NO_ACK;}
        }
        return NO_ACK;
    }
    public static Result parse(byte[] b){
        if(b==null || b.length<12 || b[0]!=4 || b[1]!=0 || b[2]!=4 || b[3]!=0 ||
            b[4]!=0x17 || b[5]!=0 || b[6]!=0 || b[7]!=0 || b[8]!=0x10 || b[9]!=0)return null;
        int payload=(b[10]&255)|((b[11]&255)<<8);
        if(payload!=b.length-12)return null;
        int seq=-1,log=-1,start=NO_ACK,command=NO_ACK, pos=12;
        while(pos<b.length){
            Varint key=readVar(b,pos,b.length);if(key==null)return null;
            pos=key.next;int field=(int)(key.value>>>3),wire=(int)(key.value&7);
            if(field==0)return null;
            if(wire==0){Varint v=readVar(b,pos,b.length);if(v==null)return null;
                pos=v.next;if(field==1)seq=(int)v.value;else if(field==2)log=(int)v.value;
            }else if(wire==2){Varint l=readVar(b,pos,b.length);if(l==null || l.value>b.length-l.next)return null;
                int e=l.next+(int)l.value;
                if(field==9)start=nestedService(b,l.next,e);
                else if(field==12)command=nestedService(b,l.next,e);
                pos=e;
            }else if(wire==1){if(b.length-pos<8)return null;pos+=8;
            }else if(wire==5){if(b.length-pos<4)return null;pos+=4;
            }else return null;
        }
        return new Result(seq,log,start,command,payload);
    }
    public static String serviceName(int s){
        if(s==14)return "ACTIVITY(14)";
        if(s==16)return "DEVMOTION6(16)";
        if(s==17)return "SPL0(17)";
        if(s<0)return "未报告";
        return "service("+s+")";
    }
    public static String summarize(byte[] frame){
        Result r=parse(frame);
        if(r==null)return "非RTBuddy 0x17信封或长度/Protobuf无效";
        String s="0x17长度="+frame.length+" 载荷="+r.payloadLength+" seq="+r.seq+" logType="+r.logType;
        if(r.startAckService>=0)s+=" StartAck="+serviceName(r.startAckService)+"（只确认请求，不证明持续输出）";
        if(r.commandAckService>=0)s+=" CommandAck="+serviceName(r.commandAckService);
        return s;
    }
}
