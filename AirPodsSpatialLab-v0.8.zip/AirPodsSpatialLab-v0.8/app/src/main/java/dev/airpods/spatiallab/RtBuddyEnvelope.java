package dev.airpods.spatiallab;

/** Diagnostic decoder for small RTBuddy SensorDataWX messages.
 * This DOES NOT infer acceptance/rejection of a head-tracking request.
 * Field names in third-party schemas can differ across firmware versions.
 */
public final class RtBuddyEnvelope {
    private RtBuddyEnvelope() {}
    public static String summarize(byte[] frame) {
        if (frame==null || frame.length<12 || (frame[4]&255)!=0x17
            || (frame[5]&255)!=0 || (frame[8]&255)!=0x10 || (frame[9]&255)!=0)
            return "非RTBuddy 0x17信封";
        int length=(frame[10]&255)|((frame[11]&255)<<8);
        if(length!=frame.length-12) return "长度字段不一致："+length+"/"+(frame.length-12);
        StringBuilder sb=new StringBuilder("0x17长度=").append(frame.length).append(" 载荷=").append(length);
        int n=0;int offset=12;
        while(offset<frame.length && n<5){
            int key=frame[offset++]&255;
            int field=key>>>3;int wire=key&7;
            if(field==0)break;
            if(wire!=0)break;
            long val=0;int shift=0;boolean complete=false;
            for(int j=0;j<5 && offset<frame.length;j++){
                int b=frame[offset++]&255;
                val|=((long)(b&127))<<shift;
                if((b&128)==0){complete=true;break;}
                shift+=7;
            }
            if(!complete)break;
            sb.append(" 字段").append(field).append('=').append(val);
            n++;
        }
        return sb.toString();
    }
}
