import dev.airpods.spatiallab.*;

public class ProtocolTests {
    private static int tested=0;
    private static void assertTrue(boolean ok,String why){tested++;if(!ok)throw new AssertionError(why);}
    public static void main(String[] args) {
        byte[] bad=new byte[80];
        assertTrue(!AacpHeadDecoder.decode(bad,bad.length),"reject junk");
        assertTrue(!AacpHeadDecoder.decode(null,0),"reject null");
        assertTrue(AacpHeadDecoder.hex("04 00").length==2,"parse hex");
        assertTrue(SpatialDiagnostics.exerciseParser().contains("通过"),"synthetic split packet");
        AacpFrameStream framer=new AacpFrameStream();
        byte[] a={9,8,7,4,0};byte[] b={4,0,1,0,0,0,4,0,4,0,2,0,0,0};
        final int[] hits={0};
        framer.accept(a,0,a.length,f->{hits[0]++;});
        framer.accept(b,0,b.length,f->{hits[0]++;});
        assertTrue(hits[0]==1,"reassemble header crossing input reads");
        HeadPose.update(35f,10f,false);HeadPose.center();
        assertTrue(Math.abs(HeadPose.yaw())<0.001f,"recenter");
        assertTrue(!HeadPose.fromAirPods(),"simulator is not real AirPods");
        SpatialProcessor dsp=new SpatialProcessor();
        byte[] samples=new byte[480*4];
        for(int i=0;i<480;i++){
            short tone=(short)(9000*Math.sin(2*Math.PI*i/48));
            samples[i*4]=(byte)tone;samples[i*4+1]=(byte)(tone>>8);
            samples[i*4+2]=(byte)tone;samples[i*4+3]=(byte)(tone>>8);
        }
        byte[] output=dsp.process(samples,samples.length,2,48000);
        int energy=0;for(byte o:output)energy|=(o&0xff);
        assertTrue(output.length==samples.length && energy!=0,"renderer nonzero PCM stereo");
        System.out.println("PASS: "+tested+" tests");
    }
}
