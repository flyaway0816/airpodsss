# A local Windows build helper. Requires Android Studio (SDK Platform 36) and internet.
# Does not download APKs from untrusted third parties.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Sdk = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } elseif ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path (Join-Path $Sdk 'platforms\android-36\android.jar'))) {
  Write-Host 'ERROR: Android SDK Platform 36 is not installed.' -ForegroundColor Red
  Write-Host 'Install Android Studio -> SDK Manager -> Android API 36, then retry.'
  exit 2
}
$env:ANDROID_HOME = $Sdk
if (-not $env:JAVA_HOME) {
  $studioJbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
  if (Test-Path (Join-Path $studioJbr 'bin\java.exe')) { $env:JAVA_HOME = $studioJbr }
}
if (-not (Get-Command java -ErrorAction SilentlyContinue) -and -not $env:JAVA_HOME) {
  Write-Host 'ERROR: Java 17+ is required (Android Studio includes a suitable JBR).'
  exit 3
}
$gradleVersion = '8.13'
$base = Join-Path $env:LOCALAPPDATA 'AirPodsSpatialLab-Build'
$exe = Join-Path $base "gradle-$gradleVersion\bin\gradle.bat"
if (-not (Test-Path $exe)) {
  New-Item -ItemType Directory -Force -Path $base | Out-Null
  $archive = Join-Path $base "gradle-$gradleVersion-bin.zip"
  $url = "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip"
  Write-Host "Downloading official Gradle $gradleVersion distribution..."
  Invoke-WebRequest -Uri $url -OutFile $archive -UseBasicParsing
  Expand-Archive -Path $archive -DestinationPath $base -Force
  Remove-Item $archive
}
Write-Host 'Building debug APK...'
Push-Location $root
try {
  & $exe --no-daemon :app:assembleDebug
  if ($LASTEXITCODE -ne 0) { throw "Gradle failed (exit code $LASTEXITCODE)" }
  $apk = Join-Path $root 'app\build\outputs\apk\debug\app-debug.apk'
  if (-not (Test-Path $apk)) { throw 'Build returned success but APK not found' }
  Write-Host "SUCCESS: $apk" -ForegroundColor Green
  Start-Process explorer.exe "/select,`"$apk`""
} finally { Pop-Location }
