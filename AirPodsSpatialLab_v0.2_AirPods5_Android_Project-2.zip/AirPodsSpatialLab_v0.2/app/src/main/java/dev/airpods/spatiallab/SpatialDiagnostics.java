package dev.airpods.spatiallab;

/** Local no-hardware test of packet splitting and the experimental layout. */
public final class SpatialDiagnostics {
    private SpatialDiagnostics() {}
    public static String exerciseParser() {
        byte[] first=new byte[72];
        first[0]=4;first[2]=4;first[4]=0x17;first[8]=0x10;
        // One candidate sample: o2=10000, o3=-10000 -> yaw 56.25 deg.
        first[45]=0x10;first[46]=0x27;first[47]=(byte)0xf0;first[48]=(byte)0xd8;
        byte[] second={4,0,4,0,1,0,0,0};
        byte[] stream=new byte[first.length+second.length];
        System.arraycopy(first,0,stream,0,first.length);
        System.arraycopy(second,0,stream,first.length,second.length);
        AacpFrameStream reader=new AacpFrameStream();
        final int[] seen={0};
        // Intentionally split a frame and reassemble it.
        for(int offset=0;offset<stream.length;offset+=7){
            int n=Math.min(7,stream.length-offset);
            reader.accept(stream,offset,n,pkt->{if(AacpHeadDecoder.decode(pkt,pkt.length))seen[0]++;});
        }
        boolean success=seen[0]==1 && Math.abs(HeadPose.yaw()-56.25f)<0.05f;
        HeadPose.update(0,0,false);
        return success ? "协议模拟自检通过：分片重组/帧筛选/角度计算均通过。注意：非真实耳机数据。"
            : "协议模拟自检失败：帧="+reader.emittedFrames()+" 有效="+seen[0];
    }
}
