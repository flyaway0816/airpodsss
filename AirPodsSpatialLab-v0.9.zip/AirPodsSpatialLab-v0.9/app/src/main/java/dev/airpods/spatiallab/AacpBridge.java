package dev.airpods.spatiallab;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.ParcelUuid;
import org.lsposed.hiddenapibypass.HiddenApiBypass;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.Locale;

/**
 * Experimental BR/EDR AACP access through Android NON-SDK APIs.
 * Hidden API policies may prevent use on Xiaomi Android 17. Does not bypass
 * root restrictions or communicate with another app's private service.
 */
public final class AacpBridge {
    public interface Callback {void status(String message);}
    private static final String SENSOR_START_DEF =
        "04 00 04 00 17 00 00 00 10 00 10 00 08 A1 02 42 0B 08 0E 10 02 1A 05 01 40 9C 00 00";
    // ALT was confirmed to trigger a live head-pose stream on AirPods 4 ANC in
    // independent hardware work; support for this AirPods 5 model is unverified.
    // Never send ALT and DEF during the same session: they can interfere.
    private static final String SENSOR_START_ALT =
        "04 00 04 00 17 00 00 00 10 00 0F 00 08 73 42 0B 08 10 10 02 1A 05 01 40 9C 00 00";
    private static final String HANDSHAKE = "00 00 04 00 01 00 02 00 00 00 00 00 00 00 00 00";
    private static final String FEATURE_FLAGS = "04 00 04 00 4D 00 D7 00 00 00 00 00 00 00";
    private static final String NOTIFICATIONS = "04 00 04 00 0F 00 FF FF FF FF";
    private final AtomicBoolean running=new AtomicBoolean(false);
    private volatile String sentPackets="本次未发送";
    private volatile String mode="未连接";
    private volatile long connectedAtMs;
    private volatile BluetoothSocket socket;
    private volatile int totalChunks, totalBytes;
    private final SensorProbe probe = new SensorProbe();
    public String diagnostics() {
        return "模式="+mode+" / L2CAP读取="+totalChunks+"次 / "+totalBytes+"字节\n"+probe.summary();
    }
    public String diagnosticReport() {
        long elapsed=connectedAtMs==0?0:android.os.SystemClock.elapsedRealtime()-connectedAtMs;
        return "AirPods Spatial Lab 0.9 | Android 17\n模式="+mode
            +"\n发送过程="+sentPackets+"\n连接后经过="+(elapsed/1000)+"秒"
            +"\nL2CAP读取="+totalChunks+"次 / "+totalBytes+"字节\n"+probe.report();
    }
    public void connect(BluetoothDevice device,Callback callback){
        connect(device, callback, true);
    }
    public void connect(BluetoothDevice device,Callback callback,boolean useAlt){
        if(!running.compareAndSet(false,true)){callback.status("AACP：已有连接尝试");return;}
        new Thread(()->{
            int receivedChunks=0;
            totalChunks=totalBytes=0;
            mode="增强初始化 + "+(useAlt?"ALT":"DEF");
            sentPackets="尚未写入";
            connectedAtMs=0;
            probe.reset();
            final int[] accepted={0};
            AacpFrameStream framer=new AacpFrameStream();
            try{
                // Classic Bluetooth BR/EDR L2CAP PSM 0x1001 is not exposed by
                // the public Android BluetoothDevice.createL2capChannel API
                // (which creates a LE credit-based channel). Newer Android
                // releases changed BluetoothSocket constructor signatures.
                // HiddenApiBypass is attempted without root; it can still fail.
                callback.status("AACP：正在探测 Android 17 蓝牙套接字构造方式（免 Root）…");
                BluetoothSocket s=createClassicL2capSocket(device,callback);
                socket=s;
                callback.status("AACP：尝试连接经典蓝牙 L2CAP PSM 0x1001…");
                s.connect();
                connectedAtMs=android.os.SystemClock.elapsedRealtime();
                callback.status("AACP：连接成功；增强初始化（握手→特性标志→通知订阅→"+(useAlt?"ALT":"DEF")+"）");
                OutputStream out=s.getOutputStream();
                StringBuilder sent=new StringBuilder();
                sendStep(out,HANDSHAKE,"握手",callback,sent);
                pause(180);
                sendStep(out,FEATURE_FLAGS,"特性标志0x4D",callback,sent);
                pause(180);
                sendStep(out,NOTIFICATIONS,"通知订阅0x0F",callback,sent);
                pause(180);
                // No arbitrary command attempts and never send both variants in one session.
                sendStep(out,useAlt ? SENSOR_START_ALT : SENSOR_START_DEF,
                         "0x17 " + (useAlt?"ALT":"DEF") + " 启动",callback,sent);
                callback.status("AACP：四步已写入；下方分开显示所有权(0x09)、StartAck与真实姿态帧。不要把StartAck当作姿态流");
                byte[] chunk=new byte[4096];InputStream in=s.getInputStream();
                while(running.get()){
                    int n=in.read(chunk);
                    if(n<0){callback.status("AACP：对端已关闭数据流");break;}
                    receivedChunks++;
                    totalChunks=receivedChunks;
                    totalBytes+=n;
                    framer.accept(chunk,0,n,frame->{
                        int before=probe.opcode17Count();
                        int ackBefore=probe.ackCount();
                        int ownBefore=probe.ownershipState();
                        boolean changed=probe.observe(frame,android.os.SystemClock.elapsedRealtime());
                        if(probe.ackCount()>ackBefore){
                            callback.status("AACP：收到启动确认："+RtBuddyEnvelope.summarize(frame)
                                +"；但尚未有实时传感器帧");
                        }
                        if(probe.ownershipState()!=ownBefore && probe.ownershipState()!=AacpControlState.UNKNOWN){
                            callback.status("AACP：连接所有权状态更新："+AacpControlState.describe(probe.ownershipState()));
                        }
                        if(before==0 && probe.opcode17Count()==1){
                            callback.status("AACP：首条0x17："+RtBuddyEnvelope.summarize(frame)
                                +"（短消息不算姿态）");
                        }
                        if(changed){
                            AacpHeadDecoder.Candidate c=AacpHeadDecoder.inspect(frame,frame.length);
                            if(c!=null){
                                accepted[0]++;
                                HeadPose.update(c.yaw,c.pitch,true);
                                if(accepted[0]==1) callback.status("AACP：发现首个数值变化的0x17候选！仍需转头动作比对，不能当作已验证的传感器。 ");
                            }
                        }
                    });
                    if(receivedChunks==25 || receivedChunks==60)
                        callback.status("AACP：收到"+receivedChunks+"个读取块。"+probe.summary());
                    if(receivedChunks%100==0)
                        callback.status("AACP：连接仍在接收。"+diagnostics());
                }
                callback.status("AACP：输入结束，数值变化候选帧="+accepted[0]);
            }catch(Throwable t){
                callback.status("AACP：连接/读取失败："+t.getClass().getSimpleName()+" / "+shortMessage(t)
                    +"。先区分构造方法、蓝牙权限、PSM 链路、帧解析四个环节；不能据此判断耳机是否支持头追。");
            }finally{running.set(false);BluetoothSocket s=socket;socket=null;
                if(s!=null)try{s.close();}catch(Exception ignored){}
            }
        },"aacp-reader").start();
    }
    private void sendStep(OutputStream out,String hex,String title,Callback cb,StringBuilder trace)
            throws IOException {
        byte[] packet=AacpHeadDecoder.hex(hex);
        out.write(packet);
        out.flush();
        if(trace.length()>0)trace.append(" → ");
        trace.append(title).append("(").append(packet.length).append("B)");
        sentPackets=trace.toString();
        cb.status("AACP：已写入"+title+"（"+packet.length+"字节，本地write完成）");
    }
    private static void pause(long ms){
        try{Thread.sleep(ms);}catch(InterruptedException e){Thread.currentThread().interrupt();}
    }

    /** Probe published LibrePods-compatible Android constructor families.
     *  Does not open LE CoC / RFCOMM as a misleading substitute for BR/EDR.
     */
    private static BluetoothSocket createClassicL2capSocket(BluetoothDevice device,Callback cb) throws Exception {
        BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
        final int TYPE_L2CAP=3;
        final int PSM_AACP=0x1001;
        // Multiple Android revisions/OEMs differ in argument order and arity.
        Object[][] candidates=new Object[][] {
            {adapter,device,TYPE_L2CAP,true,true,PSM_AACP,(ParcelUuid)null},
            {device,TYPE_L2CAP,true,true,PSM_AACP,(ParcelUuid)null},
            {device,TYPE_L2CAP,1,true,true,PSM_AACP,(ParcelUuid)null},
            {TYPE_L2CAP,1,true,true,device,PSM_AACP,(ParcelUuid)null},
            {TYPE_L2CAP,true,true,device,PSM_AACP,(ParcelUuid)null},
            {TYPE_L2CAP,1,true,true,device,PSM_AACP,(ParcelUuid)null,false,false}
        };
        Throwable last=null;
        for(int i=0;i<candidates.length;i++){
            try {
                BluetoothSocket result=(BluetoothSocket)HiddenApiBypass.newInstance(BluetoothSocket.class,candidates[i]);
                cb.status("AACP：套接字构造成功（方案 "+(i+1)+"/"+candidates.length+"），准备连接 PSM 0x1001");
                return result;
            }catch(Throwable t){
                last=t;
                cb.status("AACP：构造方案 "+(i+1)+" 未匹配（"+t.getClass().getSimpleName()+"）");
            }
        }
        throw new IllegalStateException("六种蓝牙套接字构造方式均不可用；最后原因："+shortMessage(last),last);
    }
    private static String shortMessage(Throwable t){
        if(t==null)return "unknown";
        String message=t.getMessage();
        if(message==null || message.isEmpty())return t.getClass().getSimpleName();
        return message.length()>190?message.substring(0,190):message;
    }
    public void close(){running.set(false);BluetoothSocket s=socket;socket=null;if(s!=null)try{s.close();}catch(Exception ignored){}}
}
