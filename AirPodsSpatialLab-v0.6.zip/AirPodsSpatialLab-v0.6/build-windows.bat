@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-windows.ps1"
if errorlevel 1 (
 echo.
 echo Build failed. Please review the error above.
)
pause
