#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG="$ROOT/app/src/main/java/dev/airpods/spatiallab"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -encoding UTF-8 -d "$TMP" "$PKG/HeadPose.java" "$PKG/SpatialProcessor.java" \
    "$PKG/AacpHeadDecoder.java" "$PKG/AacpFrameStream.java" "$PKG/SpatialDiagnostics.java" \
    "$ROOT/tests/ProtocolTests.java"
java -cp "$TMP" ProtocolTests
