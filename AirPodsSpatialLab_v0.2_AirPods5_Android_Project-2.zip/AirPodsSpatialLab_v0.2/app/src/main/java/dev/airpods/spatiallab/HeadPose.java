package dev.airpods.spatiallab;

/** One pose for A and B paths, in degrees, updated from a sensor or simulator. */
public final class HeadPose {
    private HeadPose() {}
    private static volatile float yaw=0f;
    private static volatile float pitch=0f;
    private static volatile float calibrationYaw=0f;
    private static volatile boolean realSensor=false;
    private static volatile long lastUpdateNanos=0L;
    public static void update(float newYaw,float newPitch,boolean fromAirPods) {
        if(!Float.isFinite(newYaw)||!Float.isFinite(newPitch))return;
        yaw=Math.max(-180f,Math.min(180f,newYaw));
        pitch=Math.max(-90f,Math.min(90f,newPitch));
        realSensor=fromAirPods;
        lastUpdateNanos=System.nanoTime();
    }
    public static float yaw(){return yaw-calibrationYaw;}
    public static float pitch(){return pitch;}
    public static void center(){calibrationYaw=yaw;}
    public static boolean fromAirPods(){return realSensor && (System.nanoTime()-lastUpdateNanos)<1_500_000_000L;}
    public static long ageMs(){return lastUpdateNanos==0L?-1L:(System.nanoTime()-lastUpdateNanos)/1_000_000L;}
}
