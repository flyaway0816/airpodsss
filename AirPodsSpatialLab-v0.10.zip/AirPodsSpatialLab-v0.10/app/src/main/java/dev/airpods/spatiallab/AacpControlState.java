package dev.airpods.spatiallab;
/** Read-only parser for AACP control status notifications, opcode 0x09.
 *  This is a diagnostic interpretation of a vendor protocol, not a command to take over.
 */
public final class AacpControlState {
    public static final int UNKNOWN=-1;
    private AacpControlState(){}
    /** AACP opcode 0x09, one identifier byte following the 6-byte header.
     *  This is a diagnostic interpretation; malformed packets are excluded. */
    public static int identifier(byte[] f){
        if(f==null || f.length<8 || f[0]!=4 || f[1]!=0 || f[2]!=4 || f[3]!=0
           || (f[4]&255)!=9 || f[5]!=0)return -1;
        return f[6]&255;
    }
    /** Up to 4 control-value bytes: never includes a Bluetooth address from other opcodes. */
    public static String valueHex(byte[] f){
        if(identifier(f)<0)return "不可识别";
        StringBuilder b=new StringBuilder();
        for(int i=7;i<Math.min(f.length,11);i++){
            if(i>7)b.append(' ');
            b.append(String.format(java.util.Locale.ROOT,"%02X",f[i]&255));
        }
        return b.toString();
    }
    /** Ownership status from control identifier 0x06; 0 / 1 are tentative. */
    public static int ownership(byte[] f){
        if(identifier(f)!=6)return UNKNOWN;
        int value=f[7]&255;
        return value==0 || value==1 ? value : UNKNOWN;
    }
    public static String describe(int state){
        if(state==1)return "1：设备报告拥有控制权（仍需验证）";
        if(state==0)return "0：设备报告未拥有控制权（仍需验证）";
        return "未知／未收到标识0x06的0x09状态";
    }
}
