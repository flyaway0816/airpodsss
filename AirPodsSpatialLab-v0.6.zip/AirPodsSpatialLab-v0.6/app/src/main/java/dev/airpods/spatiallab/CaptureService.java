package dev.airpods.spatiallab;

import android.app.*;
import android.content.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;

/** B: opt-in MediaProjection audio capture. Only allowed apps can be captured. */
public final class CaptureService extends Service {
    public static final String ACTION_START = "dev.airpods.spatiallab.START_CAPTURE";
    public static final String ACTION_STOP = "dev.airpods.spatiallab.STOP_CAPTURE";
    public static final String ACTION_UPDATE = "dev.airpods.spatiallab.STATUS";
    public static final String EXTRA_RESULT = "result";
    public static final String EXTRA_CONSENT = "consent";
    public static final String EXTRA_MONITOR = "monitor";
    private static final String CHANNEL = "spatiallab_capture";
    private volatile boolean running;
    private MediaProjection projection;
    private AudioRecord recorder;
    private AudioTrack output;
    private Thread worker;
    private final SpatialProcessor dsp = new SpatialProcessor();
    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"音频采集实验",NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_STOP.equals(intent.getAction())) { shutdown();stopSelf();return START_NOT_STICKY; }
        if (!ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;
        if (running) { report("B：已在运行，请先停止上一次采集");return START_NOT_STICKY; }
        int result = intent.getIntExtra(EXTRA_RESULT,Activity.RESULT_CANCELED);
        Intent consent = (Intent) intent.getParcelableExtra(EXTRA_CONSENT);
        boolean monitor = intent.getBooleanExtra(EXTRA_MONITOR,true);
        if (consent==null || result!=Activity.RESULT_OK) { report("B：没有获得投屏/音频采集授权");stopSelf();return START_NOT_STICKY; }
        Notification notice = new Notification.Builder(this,CHANNEL).setContentTitle("AirPods Spatial Lab")
            .setContentText(monitor ? "B：正在检测其他应用的音频（不播放）" : "B：重放实验中，可能有双音/回声")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build();
        try {
            if (Build.VERSION.SDK_INT>=29)
                startForeground(1,notice,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(1,notice);
            MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
            projection = mpm.getMediaProjection(result,consent);
            if (projection == null) throw new IllegalStateException("获取 MediaProjection 失败");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { running=false;report("B：系统撤销了授权");stopSelf(); }
            },new Handler(Looper.getMainLooper()));
            AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build();
            int min = AudioRecord.getMinBufferSize(48000,AudioFormat.CHANNEL_IN_STEREO,AudioFormat.ENCODING_PCM_16BIT);
            recorder = new AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(config)
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(48000)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build())
                .setBufferSizeInBytes(Math.max(16384,min*2)).build();
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("AudioRecord 初始化失败");
            if (!monitor) { output = Player.makeTrack(48000);output.play(); }
            recorder.startRecording();
            running=true;
            worker = new Thread(() -> loop(monitor),"app-capture-loop");worker.start();
            report(monitor ? "B：仅监测模式开启（建议先试 B站/允许采集的应用）" : "B：正在重放，可能听到原音+处理音");
        } catch (Exception e) { report("B：启动失败："+e.getMessage());shutdown();stopSelf(); }
        return START_NOT_STICKY;
    }
    private void loop(boolean monitor) {
        byte[] buf = new byte[4096];
        long lastReport=0;
        try {
            while(running && recorder != null) {
                int n = recorder.read(buf,0,buf.length,AudioRecord.READ_BLOCKING);
                if (n<=0) { if (n<0) throw new IllegalStateException("采集返回"+n); continue; }
                int frames = n/4;
                if (monitor) {
                    long now=SystemClock.elapsedRealtime();
                    if (now-lastReport>1000) {
                        double sum=0;
                        for(int i=0;i<frames*4;i+=2) { short s=(short)((buf[i]&255)|(buf[i+1]<<8));sum+=(double)s*s; }
                        int rms=(int)Math.sqrt(sum/Math.max(1,frames*2));
                        report("B：捕获音量 RMS="+rms+(rms==0?"（无音频/对方禁止采集）":"（有数据）"));lastReport=now;
                    }
                } else {
                    byte[] processed=dsp.process(buf,n,2,48000);
                    int written=0;
                    while(written<processed.length && running && output!=null) {
                        int count=output.write(processed,written,processed.length-written,AudioTrack.WRITE_BLOCKING);
                        if (count<=0) throw new IllegalStateException("回放写入失败："+count);
                        written+=count;
                    }
                }
            }
        } catch (Exception e) { report("B：采集异常："+e.getMessage()); }
        finally { running=false;stopSelf(); }
    }
    private void report(String s) { Intent msg=new Intent(ACTION_UPDATE);msg.setPackage(getPackageName());msg.putExtra("message",s);sendBroadcast(msg); }
    private void shutdown() {
        running=false;
        if (recorder!=null) {try {recorder.stop();} catch(Exception ignored){} recorder.release();recorder=null;}
        if (output!=null) {try {output.pause();output.flush();} catch(Exception ignored){} output.release();output=null;}
        if (projection!=null) {MediaProjection p=projection;projection=null;try {p.stop();}catch(Exception ignored){}}
        stopForeground(STOP_FOREGROUND_REMOVE);
    }
    @Override public void onDestroy() { shutdown();super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i) { return null; }
}
