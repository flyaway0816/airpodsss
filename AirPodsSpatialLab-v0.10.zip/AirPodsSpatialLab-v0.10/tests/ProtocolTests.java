import dev.airpods.spatiallab.*;

public class ProtocolTests {
    private static int tested=0;
    private static void assertTrue(boolean ok,String why){tested++;if(!ok)throw new AssertionError(why);}
    public static void main(String[] args) {
        byte[] bad=new byte[80];
        assertTrue(!AacpHeadDecoder.decode(bad,bad.length),"reject junk");
        assertTrue(!AacpHeadDecoder.decode(null,0),"reject null");
        assertTrue(AacpHeadDecoder.hex("04 00").length==2,"parse hex");
        assertTrue(SpatialDiagnostics.exerciseParser().contains("通过"),"synthetic split packet");
        AacpFrameStream framer=new AacpFrameStream();
        byte[] a={9,8,7,4,0};byte[] b={4,0,1,0,0,0,4,0,4,0,2,0,0,0};
        final int[] hits={0};
        framer.accept(a,0,a.length,f->{hits[0]++;});
        framer.accept(b,0,b.length,f->{hits[0]++;});
        assertTrue(hits[0]==1,"reassemble header crossing input reads");
        HeadPose.update(35f,10f,false);HeadPose.center();
        assertTrue(Math.abs(HeadPose.yaw())<0.001f,"recenter");
        // Regression: previous self-test failed after centering because it used calibrated yaw.
        assertTrue(SpatialDiagnostics.exerciseParser().contains("通过"),"synthetic self test independent of recenter");
        assertTrue(Math.abs(HeadPose.yaw())<0.001f,"self-test must not alter active pose");
        assertTrue(!HeadPose.fromAirPods(),"simulator is not real AirPods");
        SpatialProcessor dsp=new SpatialProcessor();
        byte[] samples=new byte[480*4];
        for(int i=0;i<480;i++){
            short tone=(short)(9000*Math.sin(2*Math.PI*i/48));
            samples[i*4]=(byte)tone;samples[i*4+1]=(byte)(tone>>8);
            samples[i*4+2]=(byte)tone;samples[i*4+3]=(byte)(tone>>8);
        }
        byte[] output=dsp.process(samples,samples.length,2,48000);
        int energy=0;for(byte o:output)energy|=(o&0xff);
        assertTrue(output.length==samples.length && energy!=0,"renderer nonzero PCM stereo");
        SensorProbe probe=new SensorProbe();
        // 0x17 short command is not head orientation even when present.
        byte[] short17=AacpHeadDecoder.hex("04 00 04 00 17 00 00 00 10 00 08 00 08 10 10 01 00 00 00 00");
        assertTrue(!probe.observe(short17,1000),"short command cannot carry pose");
        assertTrue(probe.opcode17Count()==1 && probe.changedCount()==0,"short command is only protocol evidence");
        // Length-delimited sensor envelopes must reconstruct across reads.
        byte[] sample=new byte[80];
        sample[0]=4;sample[2]=4;sample[4]=0x17;sample[8]=0x10;sample[10]=0x44;
        sample[45]=0x10;sample[46]=0x27; // o2=10000
        sample[47]=(byte)0xf0;sample[48]=(byte)0xd8; // o3=-10000
        assertTrue(AacpHeadDecoder.inspect(sample,80)!=null,"valid orientation-shape envelope");
        byte[] badShape=sample.clone();badShape[10]=0x42;
        assertTrue(AacpHeadDecoder.inspect(badShape,80)==null,"reject non-motion long frame");
        byte[] fake=sample.clone();fake[11]=1;
        assertTrue(AacpHeadDecoder.inspect(fake,80)==null,"reject mismatching envelope length");
        AacpFrameStream precise=new AacpFrameStream();
        final int[] got={0};
        byte[] fused=new byte[sample.length+short17.length];
        System.arraycopy(sample,0,fused,0,sample.length);
        System.arraycopy(short17,0,fused,sample.length,short17.length);
        precise.accept(fused,0,13,p->{got[0]++;});
        precise.accept(fused,13,fused.length-13,p->{got[0]++;});
        assertTrue(got[0]==2,"strict 0x17 frames consume declared bytes");
        assertTrue(!probe.observe(sample,1100),"first pose no motion correlation");
        byte[] changed=sample.clone();changed[45]=(byte)0x90;
        assertTrue(probe.observe(changed,1200),"detect changed strict orientation candidate");
        assertTrue(probe.changedCount()==1 && probe.summary().contains("数值变化=1"),"strict sensor diagnostic");
        byte[] status=AacpHeadDecoder.hex("04 00 04 00 17 00 00 00 10 00 04 00 08 07 10 03");
        assertTrue(RtBuddyEnvelope.summarize(status).contains("seq=7"),"parse RTBuddy sequence");
        assertTrue(RtBuddyEnvelope.summarize(status).contains("logType=3"),"parse RTBuddy logType");
        assertTrue(RtBuddyEnvelope.parse(status).startAckService<0,"no fake ack in short message");
        byte[] truncated=status.clone();truncated[10]=20;
        assertTrue(RtBuddyEnvelope.parse(truncated)==null,"reject corrupted RTBuddy length");
        assertTrue(RtBuddyEnvelope.summarize(AacpHeadDecoder.hex("00 00 04 00 01 00 02 00 00 00 00 00 00 00 00 00")).contains("非RTBuddy"),"reject handshake as 0x17");
        byte[] altAck=AacpHeadDecoder.hex("04 00 04 00 17 00 00 00 10 00 08 00 08 09 10 03 4A 02 08 10");
        byte[] defAck=AacpHeadDecoder.hex("04 00 04 00 17 00 00 00 10 00 08 00 08 0A 10 03 4A 02 08 0E");
        assertTrue(RtBuddyEnvelope.parse(altAck).startAckService==16,"ALT ack DEVMOTION6");
        assertTrue(RtBuddyEnvelope.parse(defAck).startAckService==14,"DEF ack ACTIVITY");
        assertTrue(RtBuddyEnvelope.summarize(altAck).contains("不证明持续输出"),"ack not stream proof");
        SensorProbe p2=new SensorProbe();
        assertTrue(!p2.observe(altAck,10) && p2.ackCount()==1,"ack increments but no pose");
        assertTrue(p2.summary().contains("DEVMOTION6"),"human readable ack");
        byte[] owned=AacpHeadDecoder.hex("04 00 04 00 09 00 06 01 00 00 00");
        byte[] notOwned=AacpHeadDecoder.hex("04 00 04 00 09 00 06 00 00 00 00");
        assertTrue(AacpControlState.ownership(owned)==1,"parse owned status");
        assertTrue(AacpControlState.ownership(notOwned)==0,"parse not-owned status");
        assertTrue(AacpControlState.ownership(defAck)==AacpControlState.UNKNOWN,"non 09 not ownership");
        assertTrue(!p2.observe(owned,20) && p2.ownershipState()==1,"passive ownership probe");
        assertTrue(p2.report().contains("控制权"),"expose ownership in report");
        assertTrue(AacpControlState.identifier(owned)==6,"identifier of ownership status");
        assertTrue(AacpControlState.valueHex(owned).equals("01 00 00 00"),"four-byte control value");
        SensorProbe readOnly=new SensorProbe();
        byte[] arbitrary=AacpHeadDecoder.hex("04 00 04 00 09 00 1A 03 00 00 00");
        assertTrue(!readOnly.observe(arbitrary,10),"0x09 is never a motion frame");
        assertTrue(readOnly.report().contains("0x1A=1条[值:03 00 00 00]"),"log ordinary control ID and value");
        assertTrue(readOnly.ownershipState()==AacpControlState.UNKNOWN,"missing ID0x06 must stay unknown");
        assertTrue(readOnly.report().contains("0x09状态帧=1条"),"count decoded ordinary status");
        assertTrue(!readOnly.observe(owned,20),"record explicit ownership status");
        assertTrue(readOnly.report().contains("0x06=1条[值:01 00 00 00]"),"summarize actual ownership status");
        assertTrue(readOnly.ownershipState()==1,"observed positive state");
        assertTrue(AacpControlState.identifier(AacpHeadDecoder.hex("04 00 04 00 09 00 03"))==-1,"reject malformed short control");
        System.out.println("PASS: "+tested+" tests");
    }
}
