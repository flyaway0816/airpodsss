package dev.airpods.spatiallab;

/**
 * Experimental AirPods head orientation decoder for AACP opcode 0x17.
 * Research: https://github.com/librepods-org/librepods/issues/719
 * This recognises ONE candidate layout, not all SensorDataWX variants.
 * Testing on AirPods 5 is required. Never claim its angles are validated.
 */
public final class AacpHeadDecoder {
    private AacpHeadDecoder() {}
    /** A candidate reading, NOT yet confirmed to represent head movement. */
    public static final class Candidate {
        public final float yaw, pitch;
        public final int raw2, raw3;
        private Candidate(float yaw,float pitch,int raw2,int raw3) {
            this.yaw=yaw;this.pitch=pitch;this.raw2=raw2;this.raw3=raw3;
        }
    }

    /** Pure decoder: never writes to global HeadPose or alters live calibration. */
    public static Candidate inspect(byte[] packet,int count) {
        if(packet==null || count<70 || count>packet.length)return null;
        if((packet[0]&255)!=4 || packet[1]!=0 || (packet[2]&255)!=4 || packet[3]!=0
                || (packet[4]&255)!=0x17 || packet[5]!=0 || (packet[8]&255)!=0x10) return null;
        // Offsets 45/47 have NOT been validated on actual AirPods 5 hardware.
        int o2=s16(packet,45),o3=s16(packet,47);
        float pitch=((o2+o3)/2.0f/32000f)*180f;
        float yaw=((o2-o3)/2.0f/32000f)*180f;
        if(!Float.isFinite(yaw)||!Float.isFinite(pitch))return null;
        if(Math.abs(pitch)>110 || Math.abs(yaw)>110)return null;
        return new Candidate(clamp(yaw,-70f,70f),clamp(pitch,-90f,90f),o2,o3);
    }

    /** Backwards compatibility for earlier parser tests and bridge. */
    public static boolean decode(byte[] packet,int count) {
        Candidate c=inspect(packet,count);
        if(c==null)return false;
        HeadPose.update(c.yaw,c.pitch,true);
        return true;
    }
    private static float clamp(float v,float min,float max){return Math.min(max,Math.max(min,v));}
    private static short s16(byte[] b,int at){return(short)((b[at]&255)|((b[at+1]&255)<<8));}
    public static byte[] hex(String src){
        String cleaned=src.replaceAll("[^0-9a-fA-F]","");
        if(cleaned.length()%2!=0)throw new IllegalArgumentException("odd hex characters");
        byte[] result=new byte[cleaned.length()/2];
        for(int i=0;i<result.length;i++)result[i]=(byte)Integer.parseInt(cleaned.substring(i*2,i*2+2),16);
        return result;
    }
}
