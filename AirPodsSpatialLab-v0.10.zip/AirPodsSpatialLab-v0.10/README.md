# AirPods Spatial Lab v0.10 (experimental)

This build addresses the exact observations from v0.9 on Xiaomi Android 17 / AirPods 5:
- AACP BR/EDR PSM 0x1001 connects successfully.
- ALT `DEVMOTION6(16)` and DEF `ACTIVITY(14)` receive protobuf StartAck.
- No long, continuously changing head-orientation frames have been confirmed.
- v0.9 saw 14 AACP opcode `0x09` control notifications, but zero notifications with identifier `0x06` (OWNS_CONNECTION). **Unknown is not the same as not owning the connection.**

## What changed in v0.10

1. Report **every observed 0x09 control identifier**, its count and up to the four state bytes (not MAC addresses), to distinguish an absent `0x06` report from a parser issue.
2. Keep ALT/DEF modes separate, preserve fully parsed StartAck and existing sensor frame diagnostics.
3. Add **one user-initiated repeat** of the same session's START command. There is no automatic takeover and no switch of requested service. Repeat only after at least 10 seconds of no sensor stream. Observe another 20 seconds.
4. Keep audio A/B routes unchanged. The sound test is **not** head-tracked HRTF audio.

## Test procedure

1. Force-stop LibrePods and connect AirPods in the phone Bluetooth settings.
2. Open Spatial Lab v0.10 and connect **enhanced ALT**. Keep both earbuds in ears.
3. Wait 10 s. If only StartAck, press `单次重发当前 START` **once**.
4. Wait 20 s, turn left/right/up/down, copy the `0x17原始帧诊断` result.
5. Share the new `0x09控制标识符与值` and `StartAck`/motion counters (do not share device addresses).

Interpretation: A missing `0x06` report is **unknown** ownership; StartAck acknowledges the requested service but does **not** prove sensor streaming. Even if input eventually works, root-free audio spatialization will only work for audio the app itself renders / media capture that other apps permit. System head tracking is not solved.

Protocol references:
- https://github.com/librepods-org/librepods/blob/main/android/app/src/main/java/me/kavishdevar/librepods/bluetooth/AACPManager.kt
- https://github.com/ntsour/Everypods/blob/main/android/app/src/main/proto/rtbuddy.proto
- https://github.com/batubozkan/pods-head-tracker
